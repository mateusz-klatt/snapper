import os
import sys

root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.append(root)

from ccxt.pro.test.base.test_order_book import test_ws_order_book  # noqa: F401
from ccxt.pro.test.base.test_cache import test_ws_cache  # noqa: F401
from ccxt.pro.test.base.test_cache_native import test_ws_cache_python_regressions  # noqa: F401  # hand-written python-only
# todo : from ccxt.pro.test.base.test_close import test_ws_close  # noqa: F401
from ccxt.pro.test.base.test_future import test_ws_future  # noqa: F401
from ccxt.pro.test.base.test_client_reset import test_ws_client_reset  # noqa: F401  # hand-written python-only
from ccxt.pro.test.base.test_abnormal_close import test_abnormal_close  # noqa: F401

async def test_base_init_ws():
    test_ws_order_book()
    test_ws_cache()
    test_ws_cache_python_regressions()  # hand-written python-only
    # todo : run(test_ws_close())
    await test_ws_future()
    await test_ws_client_reset()  # hand-written python-only
    # run(test_abnormal_close()) stays in infinite loop in travis
