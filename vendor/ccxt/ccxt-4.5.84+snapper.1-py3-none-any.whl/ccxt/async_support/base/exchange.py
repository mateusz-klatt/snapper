# -*- coding: utf-8 -*-

# -----------------------------------------------------------------------------

__version__ = '4.5.84'

# -----------------------------------------------------------------------------

import asyncio
import concurrent.futures
import socket
import certifi
import aiohttp
import ssl
import yarl
import math
from ccxt.base.types import Int, Str, Num, Strings

# -----------------------------------------------------------------------------

from ccxt.async_support.base.throttler import Throttler

# -----------------------------------------------------------------------------

from ccxt.base.errors import BadSymbol, BadRequest, BadResponse, ExchangeClosedByUser, ExchangeError, ExchangeNotAvailable, RequestTimeout, NotSupported, NullResponse, InvalidAddress, RateLimitExceeded, OperationFailed
from ccxt.base.types import ConstructorArgs, OrderType, OrderSide, OrderRequest, CancellationRequest, Order

# -----------------------------------------------------------------------------

from ccxt.base.exchange import BaseExchange as SyncExchange, ArgumentsRequired

# -----------------------------------------------------------------------------

from ccxt.async_support.base.ws.functions import inflate, gunzip
from ccxt.async_support.base.ws.client import Client
from ccxt.async_support.base.ws.future import Future
from ccxt.async_support.base.ws.order_book import OrderBook, IndexedOrderBook, CountedOrderBook


# -----------------------------------------------------------------------------

try:
    # patches aiohttp to use zlib-ng for gzip/deflate (~2x faster decompression)
    import aiohttp_fast_zlib
    aiohttp_fast_zlib.enable()
except ImportError:
    pass

# -----------------------------------------------------------------------------

__all__ = [
    'BaseExchange',
    'Exchange',
]

# -----------------------------------------------------------------------------


class BaseExchange(SyncExchange):
    synchronous = False
    streaming = {
        'maxPingPongMisses': 2,
        'keepAlive': 30000
    }
    ping = None
    newUpdates = True
    clients = {}
    timeout_on_exit = 250  # needed for: https://github.com/ccxt/ccxt/pull/23470
    closed_by_user = False

    def __init__(self, config: ConstructorArgs = {}):
        if 'asyncio_loop' in config:
            self.asyncio_loop = config['asyncio_loop']
        self.aiohttp_trust_env = config.get('aiohttp_trust_env', self.aiohttp_trust_env)
        self.verify = config.get('verify', self.verify)
        self.own_session = 'session' not in config
        self.cafile = config.get('cafile', certifi.where())
        self.throttler = None
        super(BaseExchange, self).__init__(config)
        self.markets_loading = None
        self.reloading_markets = False

    async def load_lighter_library(self, path, chainId, privateKey, apiKeyIndex, accountIndex, createClient):
        return self.load_lighter_library_helper(path, chainId, privateKey, apiKeyIndex, accountIndex, createClient)

    def get_event_loop(self):
        return self.asyncio_loop

    def init_throttler(self, cost=None):
        self.throttler = Throttler(self.tokenBucket, self.asyncio_loop)

    async def throttle(self, cost=None):
        return await self.throttler(cost)

    def get_session(self):
        return self.session

    def __del__(self):
        if self.session is not None or self.socks_proxy_sessions is not None:
            self.logger.warning(self.id + " requires to release all resources with an explicit call to the .close() coroutine. If you are using the exchange instance with async coroutines, add `await exchange.close()` to your code into a place when you're done with the exchange and don't need the exchange instance anymore (at the end of your async coroutine).")

    async def __aenter__(self):
        self.open()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self.close()

    def open(self, lazy=False):
        # a request orphaned by a failing gathered sibling can resume after close() and
        # lazily recreate a session that nobody will ever close, see issue #27418
        if lazy and self.closed_by_user:
            raise ExchangeClosedByUser(self.id + ' instance was closed by the user')
        self.closed_by_user = False
        if self.asyncio_loop is None:
            self.asyncio_loop = asyncio.get_running_loop()
            self.throttler.loop = self.asyncio_loop

        if self.ssl_context is None:
            # Create our SSL context object with our CA cert file
            self.ssl_context = ssl.create_default_context(cafile=self.cafile) if self.verify else self.verify
            if (self.ssl_context and self.safe_bool(self.options, 'include_OS_certificates', False)):
                os_default_paths = ssl.get_default_verify_paths()
                if os_default_paths.cafile and os_default_paths.cafile != self.cafile:
                    self.ssl_context.load_verify_locations(cafile=os_default_paths.cafile)

        if self.own_session and self.session is None:
            # Pass this SSL context to aiohttp and create a TCPConnector
            # family=socket.AF_UNSPEC makes dual-stack (IPv4 + IPv6) resolution explicit,
            # happy_eyeballs_delay enables RFC 8305 Happy Eyeballs to avoid IPv6 fallback stalls
            # 0 = race the other family immediately (aiohttp minimum; not Node's 10ms floor)
            self.tcp_connector = aiohttp.TCPConnector(ssl=self.ssl_context, loop=self.asyncio_loop, enable_cleanup_closed=True, family=socket.AF_UNSPEC, happy_eyeballs_delay=0)
            self.session = aiohttp.ClientSession(loop=self.asyncio_loop, connector=self.tcp_connector, trust_env=self.aiohttp_trust_env)

    async def close(self, clean_instance_data=False):
        # set before the first await, a lazy open() during close() would leak a session
        self.closed_by_user = True
        # ##### language-specific cleanup of WS & REST resources #####
        # [WS]
        await self.close_ws_clients()
        if self.session is not None:
            if self.own_session:
                await self.session.close()
            self.session = None
        await self.close_connector()
        await self.close_proxy_sessions()
        await self.sleep(self.timeout_on_exit)
        if clean_instance_data:
            self.clean_ws_data()
        # [REST]
        if clean_instance_data:
            self.clean_rest_data()

    async def close_connector(self):
        if self.tcp_connector is not None:
            await self.tcp_connector.close()
            self.tcp_connector = None
        if self.aiohttp_socks_connector is not None:
            await self.aiohttp_socks_connector.close()
            self.aiohttp_socks_connector = None

    async def close_proxy_sessions(self):
        if self.socks_proxy_sessions is not None:
            for url in self.socks_proxy_sessions:
                await self.socks_proxy_sessions[url].close()
            self.socks_proxy_sessions = None

    async def fetch(self, url, method='GET', headers=None, body=None):
        """Perform a HTTP request and return decoded JSON data"""

        # ##### PROXY & HEADERS #####
        request_headers = self.prepare_request_headers(headers)
        self.last_request_headers = request_headers
        # proxy-url
        proxyUrl = self.check_proxy_url_settings(url, method, headers, body)
        if proxyUrl is not None:
            request_headers.update({'Origin': self.origin})
            url = proxyUrl + self.url_encoder_for_proxy_url(url)
        # proxy agents
        final_proxy = None  # set default
        proxy_session = None
        httpProxy, httpsProxy, socksProxy = self.check_proxy_settings(url, method, headers, body)
        self.open(True)
        if httpProxy:
            final_proxy = httpProxy
        elif httpsProxy:
            final_proxy = httpsProxy
        elif socksProxy:
            # override session
            if (self.socks_proxy_sessions is None):
                self.socks_proxy_sessions = {}
            proxy_session = self.get_socks_proxy_session(socksProxy)
        # add aiohttp_proxy for python as exclusion
        elif self.aiohttp_proxy:
            final_proxy = self.aiohttp_proxy

        proxyAgentSet = final_proxy is not None or socksProxy is not None
        self.check_conflicting_proxies(proxyAgentSet, proxyUrl)

        # avoid old proxies mixing
        if (self.aiohttp_proxy is not None) and (proxyUrl is not None or httpProxy is not None or httpsProxy is not None or socksProxy is not None):
            raise NotSupported(self.id + ' you have set multiple proxies, please use one or another')

        # log
        if self.verbose:
            self.log("\nfetch Request:", self.id, method, url, "RequestHeaders:", request_headers, "RequestBody:", body)
        self.logger.debug("%s %s, Request: %s %s", method, url, headers, body)
        # end of proxies & headers

        request_body = body
        # check content-type is multipart/form-data for lighter
        has_multipart = False
        content_type_key = None
        for k, v in request_headers.items():
            lk = k.lower()
            if lk == 'content-type':
                if v == 'multipart/form-data':
                    content_type_key = k
                    has_multipart = True
                    data = aiohttp.FormData()
                    # TODO: attach file?
                    for k, v in body.items():
                        data.add_field(k, v)
                    encoded_body = data
                    break
                else:
                    break
        if not has_multipart:
            encoded_body = body.encode() if body else None
        else:
            # asyncio would handle it for multipart/form-data
            del request_headers[content_type_key]
        final_session = proxy_session if proxy_session is not None else self.session
        session_method = getattr(final_session, method.lower())

        http_response = None
        http_status_code = None
        http_status_text = None
        json_response = None
        try:
            async with session_method(yarl.URL(url, encoded=True),
                                      data=encoded_body,
                                      headers=request_headers,
                                      # a bare float here becomes ClientTimeout(total=N) with sock_read unset,
                                      # which can hang indefinitely on stale keep-alive connections that a proxy
                                      # or cdn silently closed, see https://github.com/ccxt/ccxt/issues/27468
                                      timeout=aiohttp.ClientTimeout(total=(self.timeout / 1000), sock_connect=(self.timeout / 1000), sock_read=(self.timeout / 1000)),
                                      proxy=final_proxy) as response:
                http_response = await response.text(errors='replace')
                # CIMultiDictProxy
                raw_headers = response.headers
                headers = {}
                for header in raw_headers:
                    if header in headers:
                        headers[header] = headers[header] + ', ' + raw_headers[header]
                    else:
                        headers[header] = raw_headers[header]
                http_status_code = response.status
                http_status_text = response.reason
                http_response = self.on_rest_response(http_status_code, http_status_text, url, method, headers, http_response, request_headers, request_body)
                json_response = self.parse_json(http_response)
                if self.enableLastHttpResponse:
                    self.last_http_response = http_response
                if self.enableLastResponseHeaders:
                    self.last_response_headers = headers
                if self.enableLastJsonResponse:
                    self.last_json_response = json_response
                if self.verbose:
                    self.log("\nfetch Response:", self.id, method, url, http_status_code, "ResponseHeaders:", headers, "ResponseBody:", http_response)
                if json_response and not isinstance(json_response, list) and self.returnResponseHeaders:
                    json_response['responseHeaders'] = headers
                self.logger.debug("%s %s, Response: %s %s %s", method, url, http_status_code, headers, http_response)

        except socket.gaierror as e:
            details = ' '.join([self.id, method, url])
            raise ExchangeNotAvailable(details) from e

        except (concurrent.futures.TimeoutError, asyncio.TimeoutError) as e:
            details = ' '.join([self.id, method, url])
            raise RequestTimeout(details) from e

        except aiohttp.ClientConnectionError as e:
            details = ' '.join([self.id, method, url])
            raise ExchangeNotAvailable(details) from e

        except aiohttp.ClientError as e:  # base exception class
            details = ' '.join([self.id, method, url])
            raise ExchangeError(details) from e

        self.handle_errors(http_status_code, http_status_text, url, method, headers, http_response, json_response, request_headers, request_body)
        self.handle_http_status_code(http_status_code, http_status_text, url, method, http_response)
        if json_response is not None:
            return json_response
        if self.is_text_response(headers):
            return http_response
        if http_response == '' or http_response is None:
            return http_response
        return response.content

    def get_socks_proxy_session(self, socksProxy):
        if (self.socks_proxy_sessions is None):
            self.socks_proxy_sessions = {}
        if (socksProxy not in self.socks_proxy_sessions):
            reverse_dns = socksProxy.startswith('socks5h://')
            socks_proxy_selected = socksProxy if not reverse_dns else socksProxy.replace('socks5h://', 'socks5://')
            try:
                from aiohttp_socks import ProxyConnector as SocksProxyConnector
            except ImportError:
                raise NotSupported(self.id + ' - SOCKS proxy requires "aiohttp_socks" module, install it with "pip install aiohttp_socks"')
            self.aiohttp_socks_connector = SocksProxyConnector.from_url(
                socks_proxy_selected,
                # extra args copied from self.open()
                ssl=self.ssl_context,
                loop=self.asyncio_loop,
                enable_cleanup_closed=True,
                rdns=reverse_dns if reverse_dns else None
            )
            self.socks_proxy_sessions[socksProxy] = aiohttp.ClientSession(loop=self.asyncio_loop, connector=self.aiohttp_socks_connector, trust_env=self.aiohttp_trust_env)
        return self.socks_proxy_sessions[socksProxy]

    async def load_markets_helper(self, reload=False, params={}):
        if not reload:
            if self.markets:
                if not self.markets_by_id:
                    return self.set_markets(self.markets)
                return self.markets
        currencies = None
        if self.has['fetchCurrencies'] is True:
            currencies = await self.fetch_currencies()
            self.options['cachedCurrencies'] = currencies
        markets = await self.fetch_markets(params)
        if 'cachedCurrencies' in self.options:
            del self.options['cachedCurrencies']
        return self.set_markets(markets, currencies)


    async def load_markets(self, reload=False, params={}):
        """
        Loads and prepares the markets for trading.

        Args:
            reload (bool): If True, the markets will be reloaded from the exchange.
            params (dict): Additional exchange-specific parameters for the request.

        Returns:
            dict: A dictionary of markets.

        Raises:
            Exception: If the markets cannot be loaded or prepared.

        Notes:
            This method is asynchronous.
            It ensures that the markets are only loaded once, even if called multiple times.
            If the markets are already loaded and `reload` is False or not provided, it returns the existing markets.
            If a reload is in progress, it waits for completion before returning.
            If an error occurs during loading or preparation, an exception is raised.
        """
        if (reload and not self.reloading_markets) or not self.markets_loading:
            self.reloading_markets = True
            coroutine = self.load_markets_helper(reload, params)
            # coroutines can only be awaited once so we wrap it in a task
            self.markets_loading = asyncio.ensure_future(coroutine)
        try:
            result = await self.markets_loading
        except asyncio.CancelledError as e:  # CancelledError is a base exception so we need to catch it explicitly
            self.reloading_markets = False
            self.markets_loading = None
            raise e
        except Exception as e:
            self.reloading_markets = False
            self.markets_loading = None
            raise e
        self.reloading_markets = False
        return result

    async def fetch_markets(self, params={}):
        # markets are returned as a list
        # currencies are returned as a dict
        # this is for historical reasons
        # and may be changed for consistency later
        return self.to_array(self.markets)

    async def fetch_currencies(self, params={}):
        # markets are returned as a list
        # currencies are returned as a dict
        # this is for historical reasons
        # and may be changed for consistency later
        return self.currencies

    async def sleep(self, milliseconds):
        return await asyncio.sleep(milliseconds / 1000)

    def spawn(self, method, *args):
        def callback(asyncio_future):
            # a cancelled task (e.g. a background snapshot fetch cancelled on close or
            # unsubscribe) raises CancelledError from .exception(), which would crash this
            # callback - propagate the cancellation to the wrapper future instead
            if asyncio_future.cancelled():
                if not future.done():
                    future.cancel()
                return
            exception = asyncio_future.exception()
            if exception is None:
                future.resolve(asyncio_future.result())
            else:
                future.reject(exception)
        future = Future()
        task = self.asyncio_loop.create_task(method(*args))
        task.add_done_callback(callback)
        return future

    #  -----------------------------------------------------------------------
    #  WS/PRO code

    @staticmethod
    def inflate(data):
        return inflate(data)

    @staticmethod
    def gunzip(data):
        return gunzip(data)

    def order_book(self, snapshot={}, depth=None):
        return OrderBook(snapshot, depth)

    def indexed_order_book(self, snapshot={}, depth=None):
        return IndexedOrderBook(snapshot, depth)

    def counted_order_book(self, snapshot={}, depth=None):
        return CountedOrderBook(snapshot, depth)

    def client(self, url):
        self.open()  # ensure self.asyncio_loop is set
        self.clients = self.clients or {}
        self.ws_dial_backoff = getattr(self, 'ws_dial_backoff', None) or {}
        if url not in self.clients:
            on_message = self.handle_message
            on_error = self.on_error
            on_close = self.on_close
            on_connected = self.on_connected
            # decide client type here: aiohttp ws / websockets / signalr / socketio
            ws_options = self.safe_value(self.options, 'ws', {})
            options = self.extend(self.streaming, {
                'log': getattr(self, 'log'),
                'ping': getattr(self, 'ping', None),
                'verbose': self.verbose,
                'throttle': Throttler(self.tokenBucket, self.asyncio_loop),
                'asyncio_loop': self.asyncio_loop,
                'decompressBinary': self.safe_bool(self.options, 'decompressBinary', True),
            }, ws_options)
            # we use aiohttp instead of fastClient now because of this
            # https://github.com/ccxt/ccxt/pull/25995
            self.clients[url] = Client(url, on_message, on_error, on_close, on_connected, options)
            # set http/s proxy (socks proxy should be set in other place)
            httpProxy, httpsProxy, socksProxy = self.check_ws_proxy_settings()
            if (httpProxy or httpsProxy):
                self.clients[url].proxy = httpProxy if httpProxy else httpsProxy
        return self.clients[url]

    def delay(self, timeout, method, *args):
        return self.asyncio_loop.call_later(timeout / 1000, self.spawn, method, *args)

    def handle_message(self, client, message):
        raise NotSupported(self.id + '.handle_message() not implemented yet')

    def watch_multiple(self, url, message_hashes, message=None, subscribe_hashes=None, subscription=None):
        # base exchange self.open starts the aiohttp Session in an async context
        self.open()
        backoff_delay = self.ws_dial_delay(url)
        client = self.client(url)

        future = Future.race([client.future(message_hash) for message_hash in message_hashes])

        missing_subscriptions = []
        if subscribe_hashes is not None:
            for subscribe_hash in subscribe_hashes:
                if subscribe_hash not in client.subscriptions:
                    missing_subscriptions.append(subscribe_hash)
                    client.subscriptions[subscribe_hash] = subscription or True

        selected_session = self.session
        # http/s proxy is being set in other places
        httpProxy, httpsProxy, socksProxy = self.check_ws_proxy_settings()
        if (socksProxy):
            selected_session = self.get_socks_proxy_session(socksProxy)
        connected = client.connected if client.connected.done() \
            else asyncio.ensure_future(client.connect(selected_session, backoff_delay))

        def after(fut):
            # todo: decouple signing from subscriptions
            options = self.safe_value(self.options, 'ws')
            cost = self.safe_value(options, 'cost', 1)
            if message:
                async def send_message():
                    if self.enableRateLimit:
                        await client.throttle(cost)
                    try:
                        await client.send(message)
                    except ConnectionError as e:
                        client.on_error(e)
                    except Exception as e:
                        client.on_error(e)
                asyncio.ensure_future(send_message())

        if missing_subscriptions:
            connected.add_done_callback(after)

        return future

    def watch(self, url, message_hash, message=None, subscribe_hash=None, subscription=None):
        # base exchange self.open starts the aiohttp Session in an async context
        self.open()
        backoff_delay = self.ws_dial_delay(url)
        client = self.client(url)
        if subscribe_hash is None and message_hash in client.futures:
            return client.futures[message_hash]
        future = client.future(message_hash)

        subscribed = client.subscriptions.get(subscribe_hash)

        if not subscribed:
            client.subscriptions[subscribe_hash] = subscription or True

        selected_session = self.session
        # http/s proxy is being set in other places
        httpProxy, httpsProxy, socksProxy = self.check_ws_proxy_settings()
        if (socksProxy):
            selected_session = self.get_socks_proxy_session(socksProxy)
        connected = client.connected if client.connected.done() \
            else asyncio.ensure_future(client.connect(selected_session, backoff_delay))

        def after(fut):
            # todo: decouple signing from subscriptions
            options = self.safe_value(self.options, 'ws')
            cost = self.safe_value(options, 'cost', 1)
            if message:
                async def send_message():
                    if self.enableRateLimit:
                        await client.throttle(cost)
                    try:
                        await client.send(message)
                    except ConnectionError as e:
                        client.on_error(e)
                    except Exception as e:
                        client.on_error(e)
                asyncio.ensure_future(send_message())

        if not subscribed:
            connected.add_done_callback(after)

        return future

    def on_connected(self, client, message=None):
        # for user hooks
        # print('Connected to', client.url)
        # a successful connection clears the dial backoff for this url
        self.ws_dial_backoff = getattr(self, 'ws_dial_backoff', None) or {}
        if client.url in self.ws_dial_backoff:
            del self.ws_dial_backoff[client.url]

    def on_error(self, client, error):
        # only genuine dial failures feed the per-url exponential backoff so
        # that fresh clients against a dead endpoint do not hammer it at
        # full rate, first dials used to bypass the reconnect backoff
        # entirely because every watch call passed backoff_delay 0.
        # Mid-session errors and the ws warn noise floor must not grow the
        # backoff, otherwise a noisy but working exchange accumulates
        # attempts and its next reconnect dial sleeps toward the cap,
        # producing test timeouts instead of noise reduction.
        # Retry-After from the failed handshake response sets the floor
        if not getattr(client, 'dial_failed', False):
            if client.url in self.clients and self.clients[client.url].error:
                del self.clients[client.url]
            return
        client.dial_failed = False
        self.ws_dial_backoff = getattr(self, 'ws_dial_backoff', None) or {}
        state = self.ws_dial_backoff.get(client.url) or {'attempts': 0}
        attempts = state['attempts'] + 1
        delay = min(30.0, 0.1 * (2 ** min(attempts, 10)))
        retry_after = getattr(client, 'last_retry_after', None)
        if retry_after is not None:
            delay = max(delay, retry_after)
        self.ws_dial_backoff[client.url] = {
            'attempts': attempts,
            'until': self.milliseconds() + int(delay * 1000),
        }
        if client.url in self.clients and self.clients[client.url].error:
            del self.clients[client.url]

    def ws_dial_delay(self, url):
        # seconds to wait before the next dial to the given url, 0 when clear
        self.ws_dial_backoff = getattr(self, 'ws_dial_backoff', None) or {}
        state = self.ws_dial_backoff.get(url)
        if not state:
            return 0
        remaining = state['until'] - self.milliseconds()
        if remaining <= 0:
            return 0
        return remaining / 1000.0

    def on_close(self, client, error):
        if client.error:
            # connection closed by the user or due to an error
            pass
        else:
            # server disconnected a working connection
            if client.url in self.clients:
                del self.clients[client.url]

    async def close_ws_clients(self):
        if self.clients:
            await asyncio.wait([asyncio.create_task(client.close()) for client in self.clients.values()], return_when=asyncio.ALL_COMPLETED)
            for url in self.clients.copy():
                del self.clients[url]

    async def load_order_book(self, client, messageHash, symbol, limit=None, params={}):
        if symbol not in self.orderbooks:
            client.reject(ExchangeError(self.id + ' loadOrderBook() orderbook is not initiated'), messageHash)
            return
        error = None
        try:
            maxRetries = self.handle_option('watchOrderBook', 'maxRetries', 3)
            tries = 0
            stored = self.orderbooks[symbol]
            while tries < maxRetries:
                cache = stored.cache
                order_book = await self.fetch_rest_order_book_safe(symbol, limit, params)
                index = self.get_cache_index(order_book, cache)
                if index >= 0:
                    stored.reset(order_book)
                    self.handle_deltas(stored, cache[index:])
                    cache.clear()
                    client.resolve(stored, messageHash)
                    return
                tries += 1
            error = ExchangeError(self.id + ' nonce is behind the cache after ' + str(maxRetries) + ' tries.')
        except Exception as e:
            error = e
        # a failed synchronization must not recurse into another attempt with the
        # same broken state - previously the except-branch invoked load_order_book
        # again, recursing endlessly when the snapshot request kept failing, see
        # https://github.com/ccxt/ccxt/pull/24224 and https://github.com/ccxt/ccxt/issues/14567
        # instead, reject the watcher and drop the connection and the cached
        # orderbook, so the next watch_order_book() call resubscribes cleanly
        client.reject(error, messageHash)
        if client.url in self.clients:
            del self.clients[client.url]
        self.orderbooks[symbol] = self.order_book()  # clear the orderbook and its cache - issue https://github.com/ccxt/ccxt/issues/26753

    def decode_proto_msg(self, data):
        try:
            from google.protobuf.json_format import MessageToDict
        except ImportError:
            raise NotSupported(self.id + ' requires protobuf to decode messages, install it with `pip install "protobuf==5.29.5"`')
        from ccxt.protobuf.mexc import PushDataV3ApiWrapper_pb2
        message = PushDataV3ApiWrapper_pb2.PushDataV3ApiWrapper()
        message.ParseFromString(data)
        dict_msg = MessageToDict(message)
        # {
        #    "channel":"spot@public.kline.v3.api.pb@BTCUSDT@Min1",
        #    "symbol":"BTCUSDT",
        #    "symbolId":"2fb942154ef44a4ab2ef98c8afb6a4a7",
        #    "createTime":"1754735110559",
        #    "publicSpotKline":{
        #       "interval":"Min1",
        #       "windowStart":"1754735100",
        #       "openingPrice":"117792.45",
        #       "closingPrice":"117805.32",
        #       "highestPrice":"117814.63",
        #       "lowestPrice":"117792.45",
        #       "volume":"0.13425465",
        #       "amount":"15815.77",
        #       "windowEnd":"1754735160"
        #    }
        # }
        return dict_msg

    async def load_dydx_protos(self):
        return

    # ########################################################################
    # ########################################################################
    # ########################################################################
    # ########################################################################
    # ########                        ########                        ########
    # ########                        ########                        ########
    # ########                        ########                        ########
    # ########                        ########                        ########
    # ########        ########################        ########################
    # ########        ########################        ########################
    # ########        ########################        ########################
    # ########        ########################        ########################
    # ########                        ########                        ########
    # ########                        ########                        ########
    # ########                        ########                        ########
    # ########                        ########                        ########
    # ########################################################################
    # ########################################################################
    # ########################################################################
    # ########################################################################
    # ########        ########        ########                        ########
    # ########        ########        ########                        ########
    # ########        ########        ########                        ########
    # ########        ########        ########                        ########
    # ################        ########################        ################
    # ################        ########################        ################
    # ################        ########################        ################
    # ################        ########################        ################
    # ########        ########        ################        ################
    # ########        ########        ################        ################
    # ########        ########        ################        ################
    # ########        ########        ################        ################
    # ########################################################################
    # ########################################################################
    # ########################################################################
    # ########################################################################

    # METHODS BELOW THIS LINE ARE TRANSPILED FROM TYPESCRIPT

    async def fetch_accounts(self, params: dict = {}):
        raise NotSupported(self.id + ' fetchAccounts() is not supported yet')

    async def watch_liquidations(self, symbol: str, since: Int = None, limit: Int = None, params: dict = {}):
        if self.has['watchLiquidationsForSymbols'] is not None and self.has['watchLiquidationsForSymbols'] is not False:
            return await self.watch_liquidations_for_symbols([symbol], since, limit, params)
        raise NotSupported(self.id + ' watchLiquidations() is not supported yet')

    async def watch_liquidations_for_symbols(self, symbols: list[str], since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' watchLiquidationsForSymbols() is not supported yet')

    async def watch_my_liquidations(self, symbol: str, since: Int = None, limit: Int = None, params: dict = {}):
        if self.has['watchMyLiquidationsForSymbols'] is not None and self.has['watchMyLiquidationsForSymbols'] is not False:
            return self.watch_my_liquidations_for_symbols([symbol], since, limit, params)
        raise NotSupported(self.id + ' watchMyLiquidations() is not supported yet')

    async def watch_my_liquidations_for_symbols(self, symbols: list[str], since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' watchMyLiquidationsForSymbols() is not supported yet')

    async def un_watch_orders(self, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' unWatchOrders() is not supported yet')

    async def un_watch_trades(self, symbol: str, params: dict = {}):
        raise NotSupported(self.id + ' unWatchTrades() is not supported yet')

    async def un_watch_trades_for_symbols(self, symbols: list[str], params: dict = {}):
        raise NotSupported(self.id + ' unWatchTradesForSymbols() is not supported yet')

    async def watch_ohlcv_for_symbols(self, symbolsAndTimeframes: list[list[str]], since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' watchOHLCVForSymbols() is not supported yet')

    async def un_watch_ohlcv_for_symbols(self, symbolsAndTimeframes: list[list[str]], params: dict = {}):
        raise NotSupported(self.id + ' unWatchOHLCVForSymbols() is not supported yet')

    async def un_watch_order_book_for_symbols(self, symbols: list[str], params: dict = {}):
        raise NotSupported(self.id + ' unWatchOrderBookForSymbols() is not supported yet')

    async def un_watch_positions(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' unWatchPositions() is not supported yet')

    async def un_watch_ticker(self, symbol: str, params: dict = {}):
        raise NotSupported(self.id + ' unWatchTicker() is not supported yet')

    async def un_watch_mark_price(self, symbol: str, params: dict = {}):
        raise NotSupported(self.id + ' unWatchMarkPrice() is not supported yet')

    async def un_watch_mark_prices(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' unWatchMarkPrices() is not supported yet')

    async def fetch_deposit_addresses(self, codes: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchDepositAddresses() is not supported yet')

    async def fetch_margin_mode(self, symbol: str, params: dict = {}):
        if self.has['fetchMarginModes'] is not None and self.has['fetchMarginModes'] is not False:
            marginModes = await self.fetch_margin_modes([symbol], params)
            return self.safe_dict(marginModes, symbol)
        else:
            raise NotSupported(self.id + ' fetchMarginMode() is not supported yet')

    async def fetch_margin_modes(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchMarginModes () is not supported yet')

    async def un_watch_order_book(self, symbol: str, params: dict = {}):
        raise NotSupported(self.id + ' unWatchOrderBook() is not supported yet')

    async def fetch_time(self, params: dict = {}):
        raise NotSupported(self.id + ' fetchTime() is not supported yet')

    async def fetch_trading_limits(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchTradingLimits() is not supported yet')

    async def fetch_cross_borrow_rates(self, params: dict = {}):
        raise NotSupported(self.id + ' fetchCrossBorrowRates() is not supported yet')

    async def fetch_isolated_borrow_rates(self, params: dict = {}):
        raise NotSupported(self.id + ' fetchIsolatedBorrowRates() is not supported yet')

    async def fetch_leverage_tiers(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchLeverageTiers() is not supported yet')

    async def fetch_funding_rates(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchFundingRates() is not supported yet')

    async def fetch_funding_intervals(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchFundingIntervals() is not supported yet')

    async def watch_funding_rate(self, symbol: str, params: dict = {}):
        raise NotSupported(self.id + ' watchFundingRate() is not supported yet')

    async def watch_funding_rates(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' watchFundingRates() is not supported yet')

    async def un_watch_funding_rates(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' unWatchFundingRates() is not supported yet')

    async def watch_funding_rates_for_symbols(self, symbols: list[str], params: dict = {}):
        return await self.watch_funding_rates(symbols, params)

    async def transfer(self, code: str, amount: float, fromAccount: str, toAccount: str, params: dict = {}):
        raise NotSupported(self.id + ' transfer() is not supported yet')

    async def withdraw(self, code: str, amount: float, address: str, tag: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' withdraw() is not supported yet')

    async def create_deposit_address(self, code: str, params: dict = {}):
        raise NotSupported(self.id + ' createDepositAddress() is not supported yet')

    async def set_leverage(self, leverage: int, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' setLeverage() is not supported yet')

    async def fetch_leverage(self, symbol: str, params: dict = {}):
        if self.has['fetchLeverages'] is not None and self.has['fetchLeverages'] is not False:
            leverages = await self.fetch_leverages([symbol], params)
            return self.safe_dict(leverages, symbol)
        else:
            raise NotSupported(self.id + ' fetchLeverage() is not supported yet')

    async def fetch_leverages(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchLeverages() is not supported yet')

    async def set_position_mode(self, hedged: bool, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' setPositionMode() is not supported yet')

    async def add_margin(self, symbol: str, amount: float, params: dict = {}):
        raise NotSupported(self.id + ' addMargin() is not supported yet')

    async def reduce_margin(self, symbol: str, amount: float, params: dict = {}):
        raise NotSupported(self.id + ' reduceMargin() is not supported yet')

    async def set_margin(self, symbol: str, amount: float, params: dict = {}):
        raise NotSupported(self.id + ' setMargin() is not supported yet')

    async def fetch_long_short_ratio(self, symbol: str, timeframe: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchLongShortRatio() is not supported yet')

    async def fetch_long_short_ratio_history(self, symbol: Str = None, timeframe: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchLongShortRatioHistory() is not supported yet')

    async def fetch_margin_adjustment_history(self, symbol: Str = None, type: Str = None, since: Num = None, limit: Num = None, params: dict = {}):
        """
        fetches the history of margin added or reduced from contract isolated positions
        :param str [symbol]: unified market symbol
        :param str [type]: "add" or "reduce"
        :param int [since]: timestamp in ms of the earliest change to fetch
        :param int [limit]: the maximum amount of changes to fetch
        :param dict params: extra parameters specific to the exchange api endpoint
        :returns dict[]: a list of `margin structures <https://docs.ccxt.com/?id=margin-loan-structure>`
        """
        raise NotSupported(self.id + ' fetchMarginAdjustmentHistory() is not supported yet')

    async def set_margin_mode(self, marginMode: str, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' setMarginMode() is not supported yet')

    async def fetch_deposit_addresses_by_network(self, code: str, params: dict = {}):
        raise NotSupported(self.id + ' fetchDepositAddressesByNetwork() is not supported yet')

    async def fetch_open_interest_history(self, symbol: str, timeframe: str = '1h', since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchOpenInterestHistory() is not supported yet')

    async def fetch_open_interests(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchOpenInterests() is not supported yet')

    async def sign_in(self, params={}):
        raise NotSupported(self.id + ' signIn() is not supported yet')

    async def fetch_payment_methods(self, params: dict = {}):
        raise NotSupported(self.id + ' fetchPaymentMethods() is not supported yet')

    async def fetch_borrow_rate(self, code: str, amount: float, params: dict = {}):
        raise NotSupported(self.id + ' fetchBorrowRate is deprecated, please use fetchCrossBorrowRate or fetchIsolatedBorrowRate instead')

    async def repay_cross_margin(self, code: str, amount: float, params: dict = {}):
        raise NotSupported(self.id + ' repayCrossMargin is not support yet')

    async def repay_isolated_margin(self, symbol: str, code: str, amount: float, params: dict = {}):
        raise NotSupported(self.id + ' repayIsolatedMargin is not support yet')

    async def borrow_cross_margin(self, code: str, amount: float, params: dict = {}):
        raise NotSupported(self.id + ' borrowCrossMargin is not support yet')

    async def borrow_isolated_margin(self, symbol: str, code: str, amount: float, params: dict = {}):
        raise NotSupported(self.id + ' borrowIsolatedMargin is not support yet')

    async def borrow_margin(self, code: str, amount: float, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' borrowMargin is deprecated, please use borrowCrossMargin or borrowIsolatedMargin instead')

    async def repay_margin(self, code: str, amount: float, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' repayMargin is deprecated, please use repayCrossMargin or repayIsolatedMargin instead')

    async def fetch_ohlcv(self, symbol: str, timeframe: str = '1m', since: Int = None, limit: Int = None, params: dict = {}):
        message = ''
        if self.has['fetchTrades'] is not None and self.has['fetchTrades'] is not False:
            message = '. If you want to build OHLCV candles from trade executions data, visit https://github.com/ccxt/ccxt/tree/master/examples/ and see "build-ohlcv-bars" file'
        raise NotSupported(self.id + ' fetchOHLCV() is not supported yet' + message)

    async def fetch_spot_ohlcv(self, symbol: str, timeframe: str = '1m', since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchSpotOHLCV() is not supported yet')

    async def fetch_contract_ohlcv(self, symbol: str, timeframe: str = '1m', since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchContractOHLCV() is not supported yet')

    async def fetch_ohlcv_ws(self, symbol: str, timeframe: str = '1m', since: Int = None, limit: Int = None, params: dict = {}):
        message = ''
        if self.has['fetchTradesWs'] is not None and self.has['fetchTradesWs'] is not False:
            message = '. If you want to build OHLCV candles from trade executions data, visit https://github.com/ccxt/ccxt/tree/master/examples/ and see "build-ohlcv-bars" file'
        raise NotSupported(self.id + ' fetchOHLCVWs() is not supported yet. Try using fetchOHLCV instead.' + message)

    async def watch_ohlcv(self, symbol: str, timeframe: str = '1m', since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' watchOHLCV() is not supported yet')

    async def fetch_web_endpoint(self, method: object, endpointMethod: object, returnAsJson: object, startRegex: Str = None, endRegex: Str = None):
        errorMessage = ''
        options = self.safe_value(self.options, method, {})
        muteOnFailure = self.safe_bool(options, 'webApiMuteFailure', True)
        try:
            # if it was not explicitly disabled, then don't fetch
            if not self.safe_bool(options, 'webApiEnable', True):
                return None
            maxRetries = self.safe_value(options, 'webApiRetries', 10)
            response = None
            retry = 0
            shouldBreak = False
            while(retry < maxRetries):
                try:
                    response = await getattr(self, endpointMethod)({})
                    shouldBreak = True
                    break
                except Exception as e:
                    retry = retry + 1
                    if retry == maxRetries:
                        raise e
                if shouldBreak:
                    break  # this is needed because of GO
            content = response
            if content is None:
                raise NullResponse(self.id + ' fetchWebEndpoint() returned empty content')
            if startRegex is not None:
                splitted_by_start = content.split(startRegex)
                content = splitted_by_start[1]  # we need second part after start
            if content is None:
                raise NullResponse(self.id + ' fetchWebEndpoint() returned empty content')
            if endRegex is not None:
                splitted_by_end = content.split(endRegex)
                content = splitted_by_end[0]  # we need first part after start
            if (returnAsJson is True) and (isinstance(content, str)):
                jsoned = self.parse_json(content.strip())  # content should be trimmed before json parsing
                if (jsoned is not None) and (jsoned is not None):
                    return jsoned  # if parsing was not successfull, exception should be thrown
                else:
                    raise BadResponse('could not parse the response into json')
            else:
                return content
        except Exception as e:
            errorMessage = self.id + ' ' + method + '() failed to fetch correct data from website. Probably webpage markup has been changed, breaking the page custom parser.'
        if muteOnFailure is True:
            return None
        else:
            raise BadResponse(errorMessage)

    async def load_trading_limits(self, symbols: Strings = None, reload=False, params: dict = {}):
        if self.has['fetchTradingLimits'] is not None and self.has['fetchTradingLimits'] is not False:
            if reload or not ('limitsLoaded' in self.options):
                response = await self.fetch_trading_limits(symbols)
                symbolsArray = self.require_value(symbols, 'loadTradingLimits() requires a symbols argument')
                markets = self.markets
                if markets is None:
                    raise ExchangeError(self.id + ' markets not loaded')
                for i in range(0, len(symbolsArray)):
                    symbol = symbolsArray[i]
                    markets[symbol] = self.deep_extend(markets[symbol], response[symbol])
                self.options['limitsLoaded'] = self.milliseconds()
        return self.markets

    async def fetch2(self, path: object, api: object = 'public', method='GET', params: dict = {}, headers: object = None, body: object = None, config={}):
        if self.enableRateLimit:
            cost = self.calculate_rate_limiter_cost(api, method, path, params, config)
            await self.throttle(cost)
        retries = 0
        retries, params = self.handle_option_and_params(params, path, 'maxRetriesOnFailure', retries)
        retryDelay = 0
        retryDelay, params = self.handle_option_and_params(params, path, 'maxRetriesOnFailureDelay', retryDelay)
        fetchDataCacheEnabled = self.fetchHistoryCacheSize > 0
        for i in range(0, retries + 1):
            fetchData = None
            if fetchDataCacheEnabled:
                fetchData = {'request': None, 'response': {'body': None}, 'error': None}
            try:
                self.set_last_rest_request_timestamp()
                request = self.sign(path, api, method, params, headers, body)
                if fetchData is not None:
                    fetchData['request'] = request
                self.set_last_request(request)
                response = await self.fetch(request['url'], request['method'], request['headers'], request['body'])
                if fetchData is not None:
                    fetchData['response']['body'] = response
                    self.add_fetch_cache(fetchData)
                return response
            except Exception as e:
                if fetchData is not None:
                    fetchData['error'] = e
                    self.add_fetch_cache(fetchData)
                if isinstance(e, OperationFailed):
                    if i < retries:
                        if self.verbose:
                            index = i + 1
                            self.log('Request failed with the error: ' + str(e) + ', retrying ' + str(index) + ' of ' + str(retries) + '...')
                        if (retryDelay is not None) and (retryDelay != 0):
                            await self.sleep(retryDelay)
                    else:
                        raise e
                else:
                    raise e
        return None  # this line is never reached, but exists for c# value return requirement

    async def request(self, path: object, api: object = 'public', method='GET', params: dict = {}, headers: object = None, body: object = None, config={}):
        return await self.fetch2(path, api, method, params, headers, body, config)

    async def load_accounts(self, reload=False, params: dict = {}):
        if reload:
            self.accounts = await self.fetch_accounts(params)
        else:
            if self.accounts is not None:
                return self.accounts
            else:
                self.accounts = await self.fetch_accounts(params)
        self.accountsById = self.index_by(self.accounts, 'id')
        return self.accounts

    async def fetch_borrow_interest(self, code: Str = None, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchBorrowInterest() is not supported yet')

    async def fetch_ledger(self, code: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchLedger() is not supported yet')

    async def fetch_ledger_entry(self, id: str, code: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchLedgerEntry() is not supported yet')

    async def fetch_balance(self, params: dict = {}):
        raise NotSupported(self.id + ' fetchBalance() is not supported yet')

    async def fetch_balance_ws(self, params: dict = {}):
        raise NotSupported(self.id + ' fetchBalanceWs() is not supported yet')

    async def watch_balance(self, params: dict = {}):
        raise NotSupported(self.id + ' watchBalance() is not supported yet')

    async def fetch_partial_balance(self, part: object, params: dict = {}):
        balance = await self.fetch_balance(params)
        return balance[part]

    async def fetch_free_balance(self, params: dict = {}):
        return await self.fetch_partial_balance('free', params)

    async def fetch_used_balance(self, params: dict = {}):
        return await self.fetch_partial_balance('used', params)

    async def fetch_total_balance(self, params: dict = {}):
        return await self.fetch_partial_balance('total', params)

    async def fetch_status(self, params: dict = {}):
        raise NotSupported(self.id + ' fetchStatus() is not supported yet')

    async def fetch_transaction_fee(self, code: str, params: dict = {}):
        if self.has['fetchTransactionFees'] is None or self.has['fetchTransactionFees'] is False:
            raise NotSupported(self.id + ' fetchTransactionFee() is not supported yet')
        return await self.fetch_transaction_fees([code], params)

    async def fetch_transaction_fees(self, codes: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchTransactionFees() is not supported yet')

    async def fetch_deposit_withdraw_fees(self, codes: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchDepositWithdrawFees() is not supported yet')

    async def fetch_deposit_withdraw_fee(self, code: str, params: dict = {}):
        if self.has['fetchDepositWithdrawFees'] is None or self.has['fetchDepositWithdrawFees'] is False:
            raise NotSupported(self.id + ' fetchDepositWithdrawFee() is not supported yet')
        fees = await self.fetch_deposit_withdraw_fees([code], params)
        return self.safe_value(fees, code)

    async def fetch_cross_borrow_rate(self, code: str, params={}):
        await self.load_markets()
        if self.has['fetchBorrowRates'] is None or self.has['fetchBorrowRates'] is False:
            raise NotSupported(self.id + ' fetchCrossBorrowRate() is not supported yet')
        borrowRates = await self.fetch_cross_borrow_rates(params)
        rate = self.safe_value(borrowRates, code)
        if rate is None:
            raise ExchangeError(self.id + ' fetchCrossBorrowRate() could not find the borrow rate for currency code ' + code)
        return rate

    async def fetch_isolated_borrow_rate(self, symbol: str, params: dict = {}):
        await self.load_markets()
        if self.has['fetchBorrowRates'] is None or self.has['fetchBorrowRates'] is False:
            raise NotSupported(self.id + ' fetchIsolatedBorrowRate() is not supported yet')
        borrowRates = await self.fetch_isolated_borrow_rates(params)
        rate = self.safe_dict(borrowRates, symbol)
        if rate is None:
            raise ExchangeError(self.id + ' fetchIsolatedBorrowRate() could not find the borrow rate for market symbol ' + symbol)
        return rate

    async def fetch_spot_tickers(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchSpotTickers() is not supported yet')

    async def fetch_contract_tickers(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchContractTickers() is not supported yet')

    async def fetch_order_books(self, symbols: Strings = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchOrderBooks() is not supported yet')

    async def un_watch_tickers(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' unWatchTickers() is not supported yet')

    async def un_watch_funding_rate(self, symbol: str, params: dict = {}):
        raise NotSupported(self.id + ' unWatchFundingRate() is not supported yet')

    async def create_twap_order(self, symbol: str, side: OrderSide, amount: float, duration: float, params: dict = {}):
        raise NotSupported(self.id + ' createTwapOrder() is not supported yet')

    async def create_convert_trade(self, id: str, fromCode: str, toCode: str, amount: Num = None, params: dict = {}):
        raise NotSupported(self.id + ' createConvertTrade() is not supported yet')

    async def fetch_convert_trade(self, id: str, code: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchConvertTrade() is not supported yet')

    async def fetch_convert_trade_history(self, code: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchConvertTradeHistory() is not supported yet')

    async def fetch_position_mode(self, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchPositionMode() is not supported yet')

    async def fetch_adl_rank(self, symbol: str, params: dict = {}):
        raise NotSupported(self.id + ' fetchADLRank() is not supported yet')

    async def fetch_positions_adl_rank(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchPositionsADLRank() is not supported yet')

    async def fetch_position_adl_rank(self, symbol: str, params: dict = {}):
        if self.has['fetchPositionsADLRank'] is not None and self.has['fetchPositionsADLRank'] is not False:
            await self.load_markets()
            market = self.market(symbol)
            symbol = market['symbol']
            ranks = await self.fetch_positions_adl_rank([symbol], params)
            rank = self.safe_dict(ranks, 0)
            if rank is None:
                raise NullResponse(self.id + ' fetchPositionsADLRank() could not find a rank for ' + symbol)
            else:
                return rank
        else:
            raise NotSupported(self.id + ' fetchPositionsADLRank() is not supported yet')

    async def create_spot_orders(self, orders: list[OrderRequest], params: dict = {}):
        raise NotSupported(self.id + ' createSpotOrders() is not supported yet')

    async def create_contract_orders(self, orders: list[OrderRequest], params: dict = {}):
        raise NotSupported(self.id + ' createContractOrders() is not supported yet')

    async def cancel_spot_order(self, id: str, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' cancelSpotOrder() is not supported yet')

    async def cancel_contract_order(self, id: str, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' cancelContractOrder() is not supported yet')

    async def cancel_all_spot_orders(self, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' cancelAllSpotOrders() is not supported yet')

    async def cancel_all_contract_orders(self, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' cancelAllContractOrders() is not supported yet')

    async def cancel_all_orders_after(self, timeout: Int, params: dict = {}):
        raise NotSupported(self.id + ' cancelAllOrdersAfter() is not supported yet')

    async def cancel_orders_for_symbols(self, orders: list[CancellationRequest], params: dict = {}):
        raise NotSupported(self.id + ' cancelOrdersForSymbols() is not supported yet')

    async def fetch_my_liquidations(self, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchMyLiquidations() is not supported yet')

    async def fetch_liquidations(self, symbol: str, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchLiquidations() is not supported yet')

    async def fetch_greeks(self, symbol: str, params: dict = {}):
        raise NotSupported(self.id + ' fetchGreeks() is not supported yet')

    async def fetch_all_greeks(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchAllGreeks() is not supported yet')

    async def fetch_option_chain(self, code: str, params: dict = {}):
        raise NotSupported(self.id + ' fetchOptionChain() is not supported yet')

    async def fetch_option(self, symbol: str, params: dict = {}):
        raise NotSupported(self.id + ' fetchOption() is not supported yet')

    async def fetch_convert_quote(self, fromCode: str, toCode: str, amount: Num = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchConvertQuote() is not supported yet')

    async def fetch_deposits_withdrawals(self, code: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        """
        fetch history of deposits and withdrawals
        :param str [code]: unified currency code for the currency of the deposit/withdrawals, default is None
        :param int [since]: timestamp in ms of the earliest deposit/withdrawal, default is None
        :param int [limit]: max number of deposit/withdrawals to return, default is None
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: a list of `transaction structures <https://docs.ccxt.com/?id=transaction-structure>`
        """
        raise NotSupported(self.id + ' fetchDepositsWithdrawals() is not supported yet')

    async def fetch_deposits(self, code: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchDeposits() is not supported yet')

    async def fetch_withdrawals(self, code: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchWithdrawals() is not supported yet')

    async def fetch_deposits_ws(self, code: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchDepositsWs() is not supported yet')

    async def fetch_withdrawals_ws(self, code: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchWithdrawalsWs() is not supported yet')

    async def fetch_funding_rate_history(self, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchFundingRateHistory() is not supported yet')

    async def fetch_funding_history(self, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchFundingHistory() is not supported yet')

    async def fetch_deposit_address(self, code: str, params: dict = {}):
        if self.has['fetchDepositAddresses'] is not None and self.has['fetchDepositAddresses'] is not False:
            depositAddresses = await self.fetch_deposit_addresses([code], params)
            depositAddress = self.safe_value(depositAddresses, code)
            if depositAddress is None:
                raise InvalidAddress(self.id + ' fetchDepositAddress() could not find a deposit address for ' + code + ', make sure you have created a corresponding deposit address in your wallet on the exchange website')
            else:
                return depositAddress
        elif self.has['fetchDepositAddressesByNetwork'] is not None and self.has['fetchDepositAddressesByNetwork'] is not False:
            network = self.safe_string(params, 'network')
            params = self.omit(params, 'network')
            addressStructures = await self.fetch_deposit_addresses_by_network(code, params)
            if network is not None:
                return self.safe_dict(addressStructures, network)
            else:
                keys = list(addressStructures.keys())
                key = keys[0]
                return self.safe_dict(addressStructures, key)
        else:
            raise NotSupported(self.id + ' fetchDepositAddress() is not supported yet')

    async def fetch_contract_deposit_address(self, code: str, params: dict = {}):
        raise NotSupported(self.id + ' fetchContractDepositAddress() is not supported yet')

    async def load_time_difference(self, params: dict = {}):
        serverTime = await self.fetch_time(params)
        after = self.milliseconds()
        if serverTime is None:
            raise ExchangeError(self.id + ' loadTimeDifference() missing serverTime')
        self.options['timeDifference'] = after - serverTime
        return self.options['timeDifference']

    async def fetch_market_leverage_tiers(self, symbol: str, params: dict = {}):
        if self.has['fetchLeverageTiers'] is not None and self.has['fetchLeverageTiers'] is not False:
            market = self.market(symbol)
            if market['contract'] is not True:
                raise BadSymbol(self.id + ' fetchMarketLeverageTiers() supports contract markets only')
            tiers = await self.fetch_leverage_tiers([symbol])
            return self.safe_value(tiers, symbol)
        else:
            raise NotSupported(self.id + ' fetchMarketLeverageTiers() is not supported yet')

    async def create_sub_account(self, name: str, params: dict = {}):
        raise NotSupported(self.id + ' createSubAccount() is not supported yet')

    async def fetch_last_prices(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchLastPrices() is not supported yet')

    async def fetch_trading_fees(self, params: dict = {}):
        raise NotSupported(self.id + ' fetchTradingFees() is not supported yet')

    async def fetch_trading_fees_ws(self, params: dict = {}):
        raise NotSupported(self.id + ' fetchTradingFeesWs() is not supported yet')

    async def fetch_convert_currencies(self, params: dict = {}):
        raise NotSupported(self.id + ' fetchConvertCurrencies() is not supported yet')

    async def fetch_funding_rate(self, symbol: str, params: dict = {}):
        if self.has['fetchFundingRates'] is not None and self.has['fetchFundingRates'] is not False:
            await self.load_markets()
            market = self.market(symbol)
            symbol = market['symbol']
            if market['contract'] is not True:
                raise BadSymbol(self.id + ' fetchFundingRate() supports contract markets only')
            rates = await self.fetch_funding_rates([symbol], params)
            rate = self.safe_value(rates, symbol)
            if rate is None:
                raise NullResponse(self.id + ' fetchFundingRate () returned no data for ' + symbol)
            else:
                return rate
        else:
            raise NotSupported(self.id + ' fetchFundingRate () is not supported yet')

    async def fetch_funding_interval(self, symbol: str, params: dict = {}):
        if self.has['fetchFundingIntervals'] is not None and self.has['fetchFundingIntervals'] is not False:
            await self.load_markets()
            market = self.market(symbol)
            symbol = market['symbol']
            if market['contract'] is not True:
                raise BadSymbol(self.id + ' fetchFundingInterval() supports contract markets only')
            rates = await self.fetch_funding_intervals([symbol], params)
            rate = self.safe_value(rates, symbol)
            if rate is None:
                raise NullResponse(self.id + ' fetchFundingInterval() returned no data for ' + symbol)
            else:
                return rate
        else:
            raise NotSupported(self.id + ' fetchFundingInterval() is not supported yet')

    async def fetch_mark_ohlcv(self, symbol: str, timeframe: str = '1m', since: Int = None, limit: Int = None, params: dict = {}):
        """
        fetches historical mark price candlestick data containing the open, high, low, and close price of a market
        :param str symbol: unified symbol of the market to fetch OHLCV data for
        :param str timeframe: the length of time each candle represents
        :param int [since]: timestamp in ms of the earliest candle to fetch
        :param int [limit]: the maximum amount of candles to fetch
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns float[][]: A list of candles ordered as timestamp, open, high, low, close, None
        """
        if self.has['fetchMarkOHLCV'] is not None and self.has['fetchMarkOHLCV'] is not False:
            request = {
                'price': 'mark',
            }
            return await self.fetch_ohlcv(symbol, timeframe, since, limit, self.extend(request, params))
        else:
            raise NotSupported(self.id + ' fetchMarkOHLCV () is not supported yet')

    async def fetch_index_ohlcv(self, symbol: str, timeframe: str = '1m', since: Int = None, limit: Int = None, params: dict = {}):
        """
        fetches historical index price candlestick data containing the open, high, low, and close price of a market
        :param str symbol: unified symbol of the market to fetch OHLCV data for
        :param str timeframe: the length of time each candle represents
        :param int [since]: timestamp in ms of the earliest candle to fetch
        :param int [limit]: the maximum amount of candles to fetch
        :param dict [params]: extra parameters specific to the exchange API endpoint
 @returns {} A list of candles ordered as timestamp, open, high, low, close, None
        """
        if self.has['fetchIndexOHLCV'] is not None and self.has['fetchIndexOHLCV'] is not False:
            request = {
                'price': 'index',
            }
            return await self.fetch_ohlcv(symbol, timeframe, since, limit, self.extend(request, params))
        else:
            raise NotSupported(self.id + ' fetchIndexOHLCV () is not supported yet')

    async def fetch_premium_index_ohlcv(self, symbol: str, timeframe: str = '1m', since: Int = None, limit: Int = None, params: dict = {}):
        """
        fetches historical premium index price candlestick data containing the open, high, low, and close price of a market
        :param str symbol: unified symbol of the market to fetch OHLCV data for
        :param str timeframe: the length of time each candle represents
        :param int [since]: timestamp in ms of the earliest candle to fetch
        :param int [limit]: the maximum amount of candles to fetch
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns float[][]: A list of candles ordered as timestamp, open, high, low, close, None
        """
        if self.has['fetchPremiumIndexOHLCV'] is not None and self.has['fetchPremiumIndexOHLCV'] is not False:
            request = {
                'price': 'premiumIndex',
            }
            return await self.fetch_ohlcv(symbol, timeframe, since, limit, self.extend(request, params))
        else:
            raise NotSupported(self.id + ' fetchPremiumIndexOHLCV () is not supported yet')

    async def fetch_transactions(self, code: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        """
 @deprecated
        *DEPRECATED* use fetchDepositsWithdrawals instead
        :param str code: unified currency code for the currency of the deposit/withdrawals, default is None
        :param int [since]: timestamp in ms of the earliest deposit/withdrawal, default is None
        :param int [limit]: max number of deposit/withdrawals to return, default is None
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: a list of `transaction structures <https://docs.ccxt.com/?id=transaction-structure>`
        """
        if self.has['fetchDepositsWithdrawals'] is not None and self.has['fetchDepositsWithdrawals'] is not False:
            return await self.fetch_deposits_withdrawals(code, since, limit, params)
        else:
            raise NotSupported(self.id + ' fetchTransactions () is not supported yet')

    async def fetch_paginated_call_dynamic(self, method: str, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}, maxEntriesPerRequest: Int = None, removeRepeated=True):
        maxCalls = 10
        maxCalls, params = self.handle_option_and_params(params, method, 'paginationCalls', maxCalls)
        maxRetries = 3
        maxRetries, params = self.handle_option_and_params(params, method, 'maxRetries', maxRetries)
        paginationDirection = None
        paginationDirection, params = self.handle_option_and_params(params, method, 'paginationDirection', 'backward')
        paginationTimestamp = None
        removeRepeatedOption = removeRepeated
        removeRepeatedOption, params = self.handle_option_and_params(params, method, 'removeRepeated', removeRepeated)
        calls = 0
        result = []
        errors = 0
        until = self.safe_integer_n(params, ['until', 'untill', 'till'])  # do not omit it from params here
        maxEntriesPerRequest, params = self.handle_max_entries_per_request_and_params(method, maxEntriesPerRequest, params)
        if (paginationDirection == 'forward'):
            if since is None:
                raise ArgumentsRequired(self.id + ' pagination requires a since argument when paginationDirection set to forward')
            paginationTimestamp = since
        while((calls < maxCalls)):
            calls += 1
            try:
                if paginationDirection == 'backward':
                    # do it backwards, starting from the last
                    # UNTIL filtering is required in order to work
                    if paginationTimestamp is not None:
                        params['until'] = paginationTimestamp - 1
                    response = await getattr(self, method)(symbol, None, maxEntriesPerRequest, params)
                    responseLength = len(response)
                    if self.verbose:
                        backwardMessage = 'Dynamic pagination call ' + self.number_to_string(calls) + ' method ' + method + ' response length ' + self.number_to_string(responseLength)
                        if paginationTimestamp is not None:
                            backwardMessage += ' timestamp ' + self.number_to_string(paginationTimestamp)
                        self.log(backwardMessage)
                    if responseLength == 0:
                        break
                    errors = 0
                    result = self.array_concat(result, response)
                    firstElement = self.safe_value(response, 0)
                    paginationTimestamp = self.safe_integer_2(firstElement, 'timestamp', 0)
                    if paginationTimestamp is None:
                        break
                    if (since is not None) and (paginationTimestamp <= since):
                        break
                else:
                    # do it forwards, starting from the since
                    response = await getattr(self, method)(symbol, paginationTimestamp, maxEntriesPerRequest, params)
                    responseLength = len(response)
                    if self.verbose:
                        forwardMessage = 'Dynamic pagination call ' + self.number_to_string(calls) + ' method ' + method + ' response length ' + self.number_to_string(responseLength)
                        if paginationTimestamp is not None:
                            forwardMessage += ' timestamp ' + self.number_to_string(paginationTimestamp)
                        self.log(forwardMessage)
                    if responseLength == 0:
                        break
                    errors = 0
                    result = self.array_concat(result, response)
                    last = self.safe_value(response, responseLength - 1)
                    lastTimestamp = self.safe_integer(last, 'timestamp', 0)
                    if lastTimestamp is None:
                        break
                    nextPaginationTimestamp = lastTimestamp + 1
                    paginationTimestamp = nextPaginationTimestamp
                    if (until is not None) and (nextPaginationTimestamp >= until):
                        break
            except Exception as e:
                errors += 1
                if errors > maxRetries:
                    raise e
        uniqueResults = result
        if removeRepeatedOption:
            uniqueResults = self.remove_repeated_elements_from_array(result)
        key = 0 if (method == 'fetchOHLCV') else 'timestamp'
        sortedRes = self.sort_by(uniqueResults, key)
        return self.filter_by_since_limit(sortedRes, since, limit, key)

    async def safe_deterministic_call(self, method: str, symbol: Str = None, since: Int = None, limit: Int = None, timeframe: Str = None, params: dict = {}):
        maxRetries = 3
        maxRetries, params = self.handle_option_and_params(params, method, 'maxRetries', maxRetries)
        errors = 0
        while(errors <= maxRetries):
            try:
                if (timeframe is not None and timeframe != '') and method != 'fetchFundingRateHistory':
                    return await getattr(self, method)(symbol, timeframe, since, limit, params)
                else:
                    return await getattr(self, method)(symbol, since, limit, params)
            except Exception as e:
                if isinstance(e, RateLimitExceeded):
                    raise e  # if we are rate limited, we should not retry and fail fast
                errors += 1
                if errors > maxRetries:
                    raise e
        return []

    async def fetch_paginated_call_deterministic(self, method: str, symbol: Str = None, since: Int = None, limit: Int = None, timeframe: Str = None, params: dict = {}, maxEntriesPerRequest: Int = None):
        maxCalls = 10
        maxCalls, params = self.handle_option_and_params(params, method, 'paginationCalls', maxCalls)
        maxEntriesPerRequest, params = self.handle_max_entries_per_request_and_params(method, maxEntriesPerRequest, params)
        # paginationDirection is only relevant to fetchPaginatedCallDynamic/Cursor; deterministic
        # pagination always walks forward internally, so strip it here to avoid leaking an
        # unrecognized param into the underlying exchange request (e.g. binance -1104 errors)
        params = self.omit(params, 'paginationDirection')
        current = self.milliseconds()
        tasks = []
        time = self.parse_timeframe(timeframe) * 1000
        maxEntriesPerRequest = self.require_value(maxEntriesPerRequest, 'fetchPaginatedCallDeterministic() maxEntriesPerRequest is required')
        step = time * maxEntriesPerRequest
        until = self.safe_integer_2(params, 'until', 'till')  # do not omit it here
        currentSince = current - (maxCalls * step) - 1
        if since is not None:
            if until is not None:
                # the recent-window floor below would jump past a fully-historical [ since, until ]
                # range and return an empty result - requiredCalls is validated against maxCalls
                # further down, so anchoring at since directly is safe here,
                # see https://github.com/ccxt/ccxt/issues/26252
                currentSince = since
            else:
                currentSince = max(currentSince, since)
        else:
            currentSince = max(currentSince, 1241440531000)  # avoid timestamps older than 2009
        if until is not None:
            if since is None:
                raise ArgumentsRequired(self.id + ' fetchPaginatedCallDeterministic() requires a since argument when until is set')
            requiredCalls = int(math.ceil((until - since)) / step)
            if requiredCalls > maxCalls:
                raise BadRequest(self.id + ' the number of required calls is greater than the max number of calls allowed, either increase the paginationCalls or decrease the since-until gap. Current paginationCalls limit is ' + str(maxCalls) + ' required calls is ' + str(requiredCalls))
        for i in range(0, maxCalls):
            if (until is not None) and (currentSince >= until):
                break
            if currentSince >= current:
                break
            tasks.append(self.safe_deterministic_call(method, symbol, currentSince, maxEntriesPerRequest, timeframe, params))
            currentSince = self.sum(currentSince, step) - 1
        results = await asyncio.gather(*tasks)
        result = []
        for i in range(0, len(results)):
            result = self.array_concat(result, results[i])
        uniqueResults = self.remove_repeated_elements_from_array(result)
        key = 0 if (method == 'fetchOHLCV') else 'timestamp'
        return self.filter_by_since_limit(uniqueResults, since, limit, key)

    async def fetch_paginated_call_cursor(self, method: str, symbol: Str | Strings = None, since: Int = None, limit: Int = None, params: dict = {}, cursorReceived: Str = None, cursorSent: Str = None, cursorIncrement: Int = None, maxEntriesPerRequest: Int = None):
        maxCalls = 10
        maxCalls, params = self.handle_option_and_params(params, method, 'paginationCalls', maxCalls)
        maxRetries = 3
        maxRetries, params = self.handle_option_and_params(params, method, 'maxRetries', maxRetries)
        maxEntriesPerRequest, params = self.handle_max_entries_per_request_and_params(method, maxEntriesPerRequest, params)
        cursorValue = None
        i = 0
        errors = 0
        result = []
        timeframe = self.safe_string(params, 'timeframe')
        params = self.omit(params, 'timeframe')  # reading the timeframe from the method arguments to avoid changing the signature
        while(i < maxCalls):
            try:
                if cursorValue is not None:
                    if cursorIncrement is not None:
                        cursorValue = self.parse_to_int(cursorValue) + cursorIncrement
                    params[cursorSent] = cursorValue
                response = None
                if method == 'fetchAccounts':
                    response = await getattr(self, method)(params)
                elif method == 'getLeverageTiersPaginated' or method == 'fetchPositions':
                    response = await getattr(self, method)(symbol, params)
                elif method == 'fetchOpenInterestHistory':
                    if not isinstance(symbol, str):
                        # fetchOpenInterestHistory takes a single symbol, never a list
                        raise ArgumentsRequired(self.id + ' fetchPaginatedCallCursor() requires a symbol argument')
                    if timeframe is None:
                        raise ArgumentsRequired(self.id + ' fetchPaginatedCallCursor() requires a timeframe argument')
                    response = await getattr(self, method)(symbol, timeframe, since, maxEntriesPerRequest, params)
                else:
                    response = await getattr(self, method)(symbol, since, maxEntriesPerRequest, params)
                errors = 0
                if response is None:
                    raise NullResponse(self.id + ' fetchPaginatedCallCursor() returned empty response')
                responseLength = len(response)
                if self.verbose:
                    cursorString = '' if (cursorValue is None) else cursorValue
                    iteration = (i + 1)
                    cursorMessage = 'Cursor pagination call ' + str(iteration) + ' method ' + method + ' response length ' + str(responseLength) + ' cursor ' + cursorString
                    self.log(cursorMessage)
                if responseLength == 0:
                    break
                if response is not None:
                    result = self.array_concat(result, response)
                last = self.safe_dict(response, responseLength - 1)
                # cursorValue = this.safeValue (last['info'], cursorReceived);
                cursorValue = None  # search for the cursor
                for j in range(0, responseLength):
                    index = responseLength - j - 1
                    entry = self.safe_dict(response, index)
                    info = self.safe_dict(entry, 'info')
                    cursor = None if (cursorReceived is None) else self.safe_value(info, cursorReceived)
                    if cursor is not None:
                        cursorValue = cursor
                        break
                if cursorValue is None:
                    break
                lastTimestamp = self.safe_integer(last, 'timestamp')
                if since is None:
                    raise ArgumentsRequired(self.id + ' fetchPaginatedCallCursor() requires a since argument')
                if lastTimestamp is not None and lastTimestamp < since:
                    break
            except Exception as e:
                errors += 1
                if errors > maxRetries:
                    raise e
            i += 1
        sorted = self.sort_cursor_paginated_result(result)
        key = 0 if (method == 'fetchOHLCV') else 'timestamp'
        return self.filter_by_since_limit(sorted, since, limit, key)

    async def fetch_paginated_call_incremental(self, method: str, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}, pageKey: Str = None, maxEntriesPerRequest: Int = None):
        maxCalls = 10
        maxCalls, params = self.handle_option_and_params(params, method, 'paginationCalls', maxCalls)
        maxRetries = 3
        maxRetries, params = self.handle_option_and_params(params, method, 'maxRetries', maxRetries)
        maxEntriesPerRequest, params = self.handle_max_entries_per_request_and_params(method, maxEntriesPerRequest, params)
        i = 0
        errors = 0
        result = []
        while(i < maxCalls):
            try:
                params[pageKey] = i + 1
                response = await getattr(self, method)(symbol, since, maxEntriesPerRequest, params)
                errors = 0
                responseLength = len(response)
                if self.verbose:
                    iteration = (i + str(1))
                    incrementalMessage = 'Incremental pagination call ' + iteration + ' method ' + method + ' response length ' + str(responseLength)
                    self.log(incrementalMessage)
                if responseLength == 0:
                    break
                result = self.array_concat(result, response)
            except Exception as e:
                errors += 1
                if errors > maxRetries:
                    raise e
            i += 1
        sorted = self.sort_cursor_paginated_result(result)
        key = 0 if (method == 'fetchOHLCV') else 'timestamp'
        return self.filter_by_since_limit(sorted, since, limit, key)

    async def load_markets_and_sign_in(self):
        await asyncio.gather(*[self.load_markets(), self.sign_in()])

    async def fetch_transfer(self, id: str, code: Str = None, params: dict = {}):
        """
        fetches a transfer
        :param str id: transfer id
        :param [str] code: unified currency code
        :param dict params: extra parameters specific to the exchange api endpoint
        :returns dict: a `transfer structure <https://docs.ccxt.com/?id=transfer-structure>`
        """
        raise NotSupported(self.id + ' fetchTransfer () is not supported yet')

    async def fetch_transfers(self, code: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        """
        fetches a transfer
        :param str id: transfer id
        :param int [since]: timestamp in ms of the earliest transfer to fetch
        :param int [limit]: the maximum amount of transfers to fetch
        :param dict params: extra parameters specific to the exchange api endpoint
        :returns dict: a `transfer structure <https://docs.ccxt.com/?id=transfer-structure>`
        """
        raise NotSupported(self.id + ' fetchTransfers () is not supported yet')

    async def un_watch_ohlcv(self, symbol: str, timeframe: str = '1m', params: dict = {}):
        """
        watches historical candlestick data containing the open, high, low, and close price, and the volume of a market
        :param str symbol: unified symbol of the market to fetch OHLCV data for
        :param str timeframe: the length of time each candle represents
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns int[][]: A list of candles ordered as timestamp, open, high, low, close, volume
        """
        raise NotSupported(self.id + ' unWatchOHLCV () is not supported yet')

    async def withdraw_ws(self, code: str, amount: float, address: str, tag: Str = None, params: dict = {}):
        """
        make a withdrawal
        :param str code: unified currency code
        :param float amount: the amount to withdraw
        :param str address: the address to withdraw to
        :param str tag:
        :param dict [params]: extra parameters specific to the bitvavo api endpoint
        :returns dict: a `transaction structure <https://docs.ccxt.com/?id=transaction-structure>`
        """
        raise NotSupported(self.id + ' withdrawWs () is not supported yet')

    async def un_watch_my_trades(self, symbol: Str = None, params: dict = {}):
        """
        unWatches information on multiple trades made by the user
        :param str symbol: unified market symbol of the market orders were made in
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict[]: a list of `order structures <https://docs.ccxt.com/?id=order-structure>`
        """
        raise NotSupported(self.id + ' unWatchMyTrades () is not supported yet')

    async def fetch_orders_by_status_ws(self, status: str, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        """
        watches information on open orders with bid(buy) and ask(sell) prices, volumes and other data
        :param str symbol: unified symbol of the market to fetch the order book for
        :param int [limit]: the maximum amount of order book entries to return
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict[]: a list of `order structures <https://docs.ccxt.com/?id=order-structure>`
        """
        raise NotSupported(self.id + ' fetchOrdersByStatusWs () is not supported yet')

    async def un_watch_bids_asks(self, symbols: Strings = None, params: dict = {}):
        """
        unWatches best bid & ask for symbols
        :param str[] symbols: unified symbol of the market to fetch the ticker for
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: a `ticker structure <https://docs.ccxt.com/?id=ticker-structure>`
        """
        raise NotSupported(self.id + ' unWatchBidsAsks () is not supported yet')

    async def is_uta_enabled(self, params: dict = {}):
        return False  # stub


class Exchange(BaseExchange):

    async def close_position(self, symbol: str, side: OrderSide = None, params: dict = {}):
        raise NotSupported(self.id + ' closePosition() is not supported yet')

    async def close_all_positions(self, params: dict = {}):
        raise NotSupported(self.id + ' closeAllPositions() is not supported yet')

    async def edit_orders(self, orders: list[OrderRequest], params: dict = {}):
        raise NotSupported(self.id + ' editOrders() is not supported yet')

    async def fetch_canceled_and_closed_orders(self, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchCanceledAndClosedOrders() is not supported yet')

    async def fetch_position_history(self, symbol: str, since: Int = None, limit: Int = None, params: dict = {}):
        """
        fetches the history of margin added or reduced from contract isolated positions
        :param str [symbol]: unified market symbol
        :param int [since]: timestamp in ms of the position
        :param int [limit]: the maximum amount of candles to fetch, default=1000
        :param dict params: extra parameters specific to the exchange api endpoint
        :returns dict[]: a list of `position structures <https://docs.ccxt.com/?id=position-structure>`
        """
        if self.has['fetchPositionsHistory'] is not None and self.has['fetchPositionsHistory'] is not False:
            positions = await self.fetchPositionsHistory([symbol], since, limit, params)
            return positions
        else:
            raise NotSupported(self.id + ' fetchPositionHistory () is not supported yet')

    async def fetch_positions_history(self, symbols: Strings = None, since: Int = None, limit: Int = None, params: dict = {}):
        """
        fetches the history of margin added or reduced from contract isolated positions
        :param str [symbol]: unified market symbol
        :param int [since]: timestamp in ms of the position
        :param int [limit]: the maximum amount of candles to fetch, default=1000
        :param dict params: extra parameters specific to the exchange api endpoint
        :returns dict[]: a list of `position structures <https://docs.ccxt.com/?id=position-structure>`
        """
        raise NotSupported(self.id + ' fetchPositionsHistory () is not supported yet')

    async def fetch_positions_risk(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchPositionsRisk() is not supported yet')

    async def fetch_positions_for_symbol(self, symbol: str, params: dict = {}):
        """
        fetches all open positions for specific symbol, unlike fetchPositions(which is designed to work with multiple symbols) so self method might be preffered for one-market position, because of less rate-limit consumption and speed
        :param str symbol: unified market symbol
        :param dict params: extra parameters specific to the endpoint
        :returns dict[]: a list of `position structure <https://docs.ccxt.com/?id=position-structure>` with maximum 3 items - possible one position for "one-way" mode, and possible two positions(long & short) for "two-way"(a.k.a. hedge) mode
        """
        raise NotSupported(self.id + ' fetchPositionsForSymbol() is not supported yet')

    async def fetch_positions_for_symbol_ws(self, symbol: str, params: dict = {}):
        """
        fetches all open positions for specific symbol, unlike fetchPositions(which is designed to work with multiple symbols) so self method might be preffered for one-market position, because of less rate-limit consumption and speed
        :param str symbol: unified market symbol
        :param dict params: extra parameters specific to the endpoint
        :returns dict[]: a list of `position structure <https://docs.ccxt.com/?id=position-structure>` with maximum 3 items - possible one position for "one-way" mode, and possible two positions(long & short) for "two-way"(a.k.a. hedge) mode
        """
        raise NotSupported(self.id + ' fetchPositionsForSymbol() is not supported yet')

    async def watch_position(self, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' watchPosition() is not supported yet')

    async def watch_my_trades_for_symbols(self, symbols: list[str], since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' watchMyTradesForSymbols() is not supported yet')

    async def watch_trades_for_symbols(self, symbols: list[str], since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' watchTradesForSymbols() is not supported yet')

    async def fetch_bids_asks(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchBidsAsks() is not supported yet')

    async def fetch_mark_price(self, symbol: str, params: dict = {}):
        if self.has['fetchMarkPrices'] is not None and self.has['fetchMarkPrices'] is not False:
            await self.load_markets()
            market = self.market(symbol)
            symbol = market['symbol']
            tickers = await self.fetchMarkPrices([symbol], params)
            ticker = self.safe_dict(tickers, symbol)
            if ticker is None:
                raise NullResponse(self.id + ' fetchMarkPrices() could not find a ticker for ' + symbol)
            else:
                return ticker
        else:
            raise NotSupported(self.id + ' fetchMarkPrices() is not supported yet')

    async def fetch_mark_prices(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchMarkPrices() is not supported yet')

    async def watch_bids_asks(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' watchBidsAsks() is not supported yet')

    async def watch_mark_price(self, symbol: str, params: dict = {}):
        """
        watches a mark price for a specific market
        :param str symbol: unified symbol of the market to fetch the ticker for
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: a `ticker structure <https://docs.ccxt.com/?id=ticker-structure>`
        """
        raise NotSupported(self.id + ' watchMarkPrice () is not supported yet')

    async def watch_mark_prices(self, symbols: Strings = None, params: dict = {}):
        """
        watches the mark price for all markets
        :param str[] symbols: unified symbol of the market to fetch the ticker for
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: a `ticker structure <https://docs.ccxt.com/?id=ticker-structure>`
        """
        raise NotSupported(self.id + ' watchMarkPrices () is not supported yet')

    async def fetch_l3_order_book(self, symbol: str, limit: Int = None, params: dict = {}):
        raise BadRequest(self.id + ' fetchL3OrderBook() is not supported yet')

    async def watch_order_book_for_symbols(self, symbols: list[str], limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' watchOrderBookForSymbols() is not supported yet')

    async def watch_orders_for_symbols(self, symbols: list[str], since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' watchOrdersForSymbols() is not supported yet')

    async def cancel_all_orders_ws(self, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' cancelAllOrdersWs() is not supported yet')

    async def cancel_order_ws(self, id: str, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' cancelOrderWs() is not supported yet')

    async def cancel_orders_ws(self, ids: list[str], symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' cancelOrdersWs() is not supported yet')

    async def create_limit_buy_order_ws(self, symbol: str, amount: float, price: float, params: dict = {}):
        return await self.createOrderWs(symbol, 'limit', 'buy', amount, price, params)

    async def create_limit_order_ws(self, symbol: str, side: OrderSide, amount: float, price: float, params: dict = {}):
        return await self.createOrderWs(symbol, 'limit', side, amount, price, params)

    async def create_limit_sell_order_ws(self, symbol: str, amount: float, price: float, params: dict = {}):
        return await self.createOrderWs(symbol, 'limit', 'sell', amount, price, params)

    async def create_market_buy_order_ws(self, symbol: str, amount: float, params: dict = {}):
        return await self.createOrderWs(symbol, 'market', 'buy', amount, None, params)

    async def create_market_order_with_cost_ws(self, symbol: str, side: OrderSide, cost: float, params: dict = {}):
        """
        create a market order by providing the symbol, side and cost
        :param str symbol: unified symbol of the market to create an order in
        :param str side: 'buy' or 'sell'
        :param float cost: how much you want to trade in units of the quote currency
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        if (self.has['createMarketOrderWithCostWs'] is not None and self.has['createMarketOrderWithCostWs'] is not False) or ((self.has['createMarketBuyOrderWithCostWs'] is not None and self.has['createMarketBuyOrderWithCostWs'] is not False) and (self.has['createMarketSellOrderWithCostWs'] is not None and self.has['createMarketSellOrderWithCostWs'] is not False)):
            return await self.createOrderWs(symbol, 'market', side, cost, 1, params)
        raise NotSupported(self.id + ' createMarketOrderWithCostWs() is not supported yet')

    async def create_market_order_ws(self, symbol: str, side: OrderSide, amount: float, price: Num = None, params: dict = {}):
        return await self.createOrderWs(symbol, 'market', side, amount, price, params)

    async def create_market_sell_order_ws(self, symbol: str, amount: float, params: dict = {}):
        return await self.createOrderWs(symbol, 'market', 'sell', amount, None, params)

    async def create_order_with_take_profit_and_stop_loss_ws(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, takeProfit: Num = None, stopLoss: Num = None, params: dict = {}):
        """
        create an order with a stop loss or take profit attached(type 3)
        :param str symbol: unified symbol of the market to create an order in
        :param str type: 'market' or 'limit'
        :param str side: 'buy' or 'sell'
        :param float amount: how much you want to trade in units of the base currency or the number of contracts
        :param float [price]: the price to fulfill the order, in units of the quote currency, ignored in market orders
        :param float [takeProfit]: the take profit price, in units of the quote currency
        :param float [stopLoss]: the stop loss price, in units of the quote currency
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :param str [params.takeProfitType]: *not available on all exchanges* 'limit' or 'market'
        :param str [params.stopLossType]: *not available on all exchanges* 'limit' or 'market'
        :param str [params.takeProfitPriceType]: *not available on all exchanges* 'last', 'mark' or 'index'
        :param str [params.stopLossPriceType]: *not available on all exchanges* 'last', 'mark' or 'index'
        :param float [params.takeProfitLimitPrice]: *not available on all exchanges* limit price for a limit take profit order
        :param float [params.stopLossLimitPrice]: *not available on all exchanges* stop loss for a limit stop loss order
        :param float [params.takeProfitAmount]: *not available on all exchanges* the amount for a take profit
        :param float [params.stopLossAmount]: *not available on all exchanges* the amount for a stop loss
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        params = self.set_take_profit_and_stop_loss_params(symbol, type, side, amount, price, takeProfit, stopLoss, params)
        if self.has['createOrderWithTakeProfitAndStopLossWs'] is not None and self.has['createOrderWithTakeProfitAndStopLossWs'] is not False:
            return await self.createOrderWs(symbol, type, side, amount, price, params)
        raise NotSupported(self.id + ' createOrderWithTakeProfitAndStopLossWs() is not supported yet')

    async def create_order_ws(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, params: dict = {}):
        raise NotSupported(self.id + ' createOrderWs() is not supported yet')

    async def create_orders_ws(self, orders: list[OrderRequest], params: dict = {}):
        """
        create a list of trade orders
        :param Array orders: list of orders to create, each object should contain the parameters required by createOrder, namely symbol, type, side, amount, price and params
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        raise NotSupported(self.id + ' createOrdersWs () is not supported yet')

    async def create_post_only_order_ws(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, params: dict = {}):
        if self.has['createPostOnlyOrderWs'] is None or self.has['createPostOnlyOrderWs'] is False:
            raise NotSupported(self.id + ' createPostOnlyOrderWs() is not supported yet')
        query = self.extend(params, {'postOnly': True})
        return await self.createOrderWs(symbol, type, side, amount, price, query)

    async def create_reduce_only_order_ws(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, params: dict = {}):
        if self.has['createReduceOnlyOrderWs'] is None or self.has['createReduceOnlyOrderWs'] is False:
            raise NotSupported(self.id + ' createReduceOnlyOrderWs() is not supported yet')
        query = self.extend(params, {'reduceOnly': True})
        return await self.createOrderWs(symbol, type, side, amount, price, query)

    async def create_stop_limit_order_ws(self, symbol: str, side: OrderSide, amount: float, price: float, triggerPrice: float, params: dict = {}):
        if self.has['createStopLimitOrderWs'] is None or self.has['createStopLimitOrderWs'] is False:
            raise NotSupported(self.id + ' createStopLimitOrderWs() is not supported yet')
        query = self.extend(params, {'stopPrice': triggerPrice})
        return await self.createOrderWs(symbol, 'limit', side, amount, price, query)

    async def create_stop_loss_order_ws(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, stopLossPrice: Num = None, params: dict = {}):
        """
        create a trigger stop loss order(type 2)
        :param str symbol: unified symbol of the market to create an order in
        :param str type: 'market' or 'limit'
        :param str side: 'buy' or 'sell'
        :param float amount: how much you want to trade in units of the base currency or the number of contracts
        :param float [price]: the price to fulfill the order, in units of the quote currency, ignored in market orders
        :param float stopLossPrice: the price to trigger the stop loss order, in units of the quote currency
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        if stopLossPrice is None:
            raise ArgumentsRequired(self.id + ' createStopLossOrderWs() requires a stopLossPrice argument')
        params = self.extend(params, {'stopLossPrice': stopLossPrice})
        if self.has['createStopLossOrderWs'] is not None and self.has['createStopLossOrderWs'] is not False:
            return await self.createOrderWs(symbol, type, side, amount, price, params)
        raise NotSupported(self.id + ' createStopLossOrderWs() is not supported yet')

    async def create_stop_market_order_ws(self, symbol: str, side: OrderSide, amount: float, triggerPrice: float, params: dict = {}):
        if self.has['createStopMarketOrderWs'] is None or self.has['createStopMarketOrderWs'] is False:
            raise NotSupported(self.id + ' createStopMarketOrderWs() is not supported yet')
        query = self.extend(params, {'stopPrice': triggerPrice})
        return await self.createOrderWs(symbol, 'market', side, amount, None, query)

    async def create_stop_order_ws(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, triggerPrice: Num = None, params: dict = {}):
        if self.has['createStopOrderWs'] is None or self.has['createStopOrderWs'] is False:
            raise NotSupported(self.id + ' createStopOrderWs() is not supported yet')
        if triggerPrice is None:
            raise ArgumentsRequired(self.id + ' createStopOrderWs() requires a stopPrice argument')
        query = self.extend(params, {'stopPrice': triggerPrice})
        return await self.createOrderWs(symbol, type, side, amount, price, query)

    async def create_take_profit_order_ws(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, takeProfitPrice: Num = None, params: dict = {}):
        """
        create a trigger take profit order(type 2)
        :param str symbol: unified symbol of the market to create an order in
        :param str type: 'market' or 'limit'
        :param str side: 'buy' or 'sell'
        :param float amount: how much you want to trade in units of the base currency or the number of contracts
        :param float [price]: the price to fulfill the order, in units of the quote currency, ignored in market orders
        :param float takeProfitPrice: the price to trigger the take profit order, in units of the quote currency
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        if takeProfitPrice is None:
            raise ArgumentsRequired(self.id + ' createTakeProfitOrderWs() requires a takeProfitPrice argument')
        params = self.extend(params, {'takeProfitPrice': takeProfitPrice})
        if self.has['createTakeProfitOrderWs'] is not None and self.has['createTakeProfitOrderWs'] is not False:
            return await self.createOrderWs(symbol, type, side, amount, price, params)
        raise NotSupported(self.id + ' createTakeProfitOrderWs() is not supported yet')

    async def create_trailing_amount_order_ws(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, trailingAmount: Num = None, trailingTriggerPrice: Num = None, params: dict = {}):
        """
        create a trailing order by providing the symbol, type, side, amount, price and trailingAmount
        :param str symbol: unified symbol of the market to create an order in
        :param str type: 'market' or 'limit'
        :param str side: 'buy' or 'sell'
        :param float amount: how much you want to trade in units of the base currency, or number of contracts
        :param float [price]: the price for the order to be filled at, in units of the quote currency, ignored in market orders
        :param float trailingAmount: the quote amount to trail away from the current market price
        :param float [trailingTriggerPrice]: the price to activate a trailing order, default uses the price argument
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        if trailingAmount is None:
            raise ArgumentsRequired(self.id + ' createTrailingAmountOrderWs() requires a trailingAmount argument')
        params['trailingAmount'] = trailingAmount
        if trailingTriggerPrice is not None:
            params['trailingTriggerPrice'] = trailingTriggerPrice
        if self.has['createTrailingAmountOrderWs'] is not None and self.has['createTrailingAmountOrderWs'] is not False:
            return await self.createOrderWs(symbol, type, side, amount, price, params)
        raise NotSupported(self.id + ' createTrailingAmountOrderWs() is not supported yet')

    async def create_trailing_percent_order_ws(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, trailingPercent: Num = None, trailingTriggerPrice: Num = None, params: dict = {}):
        """
        create a trailing order by providing the symbol, type, side, amount, price and trailingPercent
        :param str symbol: unified symbol of the market to create an order in
        :param str type: 'market' or 'limit'
        :param str side: 'buy' or 'sell'
        :param float amount: how much you want to trade in units of the base currency, or number of contracts
        :param float [price]: the price for the order to be filled at, in units of the quote currency, ignored in market orders
        :param float trailingPercent: the percent to trail away from the current market price
        :param float [trailingTriggerPrice]: the price to activate a trailing order, default uses the price argument
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        if trailingPercent is None:
            raise ArgumentsRequired(self.id + ' createTrailingPercentOrderWs() requires a trailingPercent argument')
        params['trailingPercent'] = trailingPercent
        if trailingTriggerPrice is not None:
            params['trailingTriggerPrice'] = trailingTriggerPrice
        if self.has['createTrailingPercentOrderWs'] is not None and self.has['createTrailingPercentOrderWs'] is not False:
            return await self.createOrderWs(symbol, type, side, amount, price, params)
        raise NotSupported(self.id + ' createTrailingPercentOrderWs() is not supported yet')

    async def create_trigger_order_ws(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, triggerPrice: Num = None, params: dict = {}):
        """
        create a trigger stop order(type 1)
        :param str symbol: unified symbol of the market to create an order in
        :param str type: 'market' or 'limit'
        :param str side: 'buy' or 'sell'
        :param float amount: how much you want to trade in units of the base currency or the number of contracts
        :param float [price]: the price to fulfill the order, in units of the quote currency, ignored in market orders
        :param float triggerPrice: the price to trigger the stop order, in units of the quote currency
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        if triggerPrice is None:
            raise ArgumentsRequired(self.id + ' createTriggerOrderWs() requires a triggerPrice argument')
        params = self.extend(params, {'triggerPrice': triggerPrice})
        if self.has['createTriggerOrderWs'] is not None and self.has['createTriggerOrderWs'] is not False:
            return await self.createOrderWs(symbol, type, side, amount, price, params)
        raise NotSupported(self.id + ' createTriggerOrderWs() is not supported yet')

    async def edit_order_ws(self, id: str, symbol: str, type: OrderType, side: OrderSide, amount: Num = None, price: Num = None, params: dict = {}):
        await self.cancelOrderWs(id, symbol)
        return await self.createOrderWs(symbol, type, side, amount, price, params)

    async def fetch_closed_orders_ws(self, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        if self.has['fetchOrdersWs'] is not None and self.has['fetchOrdersWs'] is not False:
            orders = await self.fetchOrdersWs(symbol, since, limit, params)
            return self.filter_by(orders, 'status', 'closed')
        raise NotSupported(self.id + ' fetchClosedOrdersWs() is not supported yet')

    async def fetch_my_trades_ws(self, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchMyTradesWs() is not supported yet')

    async def fetch_open_orders_ws(self, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        if self.has['fetchOrdersWs'] is not None and self.has['fetchOrdersWs'] is not False:
            orders = await self.fetchOrdersWs(symbol, since, limit, params)
            return self.filter_by(orders, 'status', 'open')
        raise NotSupported(self.id + ' fetchOpenOrdersWs() is not supported yet')

    async def fetch_order_book_ws(self, symbol: str, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchOrderBookWs() is not supported yet')

    async def fetch_order_ws(self, id: str, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchOrderWs() is not supported yet')

    async def fetch_orders_ws(self, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchOrdersWs() is not supported yet')

    async def fetch_position_ws(self, symbol: str, params: dict = {}):
        raise NotSupported(self.id + ' fetchPositionWs() is not supported yet')

    async def fetch_positions_ws(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchPositions() is not supported yet')

    async def fetch_ticker_ws(self, symbol: str, params: dict = {}):
        if self.has['fetchTickersWs'] is not None and self.has['fetchTickersWs'] is not False:
            await self.load_markets()
            market = self.market(symbol)
            symbol = market['symbol']
            tickers = await self.fetchTickersWs([symbol], params)
            ticker = self.safe_dict(tickers, symbol)
            if ticker is None:
                raise NullResponse(self.id + ' fetchTickerWs() could not find a ticker for ' + symbol)
            else:
                return ticker
        else:
            raise NotSupported(self.id + ' fetchTickerWs() is not supported yet')

    async def fetch_tickers_ws(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchTickersWs() is not supported yet')

    async def fetch_trades_ws(self, symbol: str, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchTradesWs() is not supported yet')

    async def fetch_trades(self, symbol: str, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchTrades() is not supported yet')

    async def watch_trades(self, symbol: str, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' watchTrades() is not supported yet')

    async def fetch_order_book(self, symbol: str, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchOrderBook() is not supported yet')

    async def fetch_rest_order_book_safe(self, symbol: object, limit: Int = None, params: dict = {}):
        fetchSnapshotMaxRetries = self.handle_option('watchOrderBook', 'maxRetries', 3)
        for i in range(0, fetchSnapshotMaxRetries):
            try:
                orderBook = await self.fetch_order_book(symbol, limit, params)
                return orderBook
            except Exception as e:
                if (i + 1) == fetchSnapshotMaxRetries:
                    raise e
        return None

    async def watch_order_book(self, symbol: str, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' watchOrderBook() is not supported yet')

    async def fetch_open_interest(self, symbol: str, params: dict = {}):
        if self.has['fetchOpenInterests'] is not None and self.has['fetchOpenInterests'] is not False:
            openInterests = await self.fetch_open_interests([symbol], params)
            return self.safe_dict(openInterests, symbol)
        else:
            raise NotSupported(self.id + ' fetchOpenInterest() is not supported yet')

    async def fetch_l2_order_book(self, symbol: str, limit: Int = None, params: dict = {}):
        orderbook = await self.fetch_order_book(symbol, limit, params)
        return self.extend(orderbook, {
            'asks': self.sort_by(self.aggregate(orderbook['asks']), 0),
            'bids': self.sort_by(self.aggregate(orderbook['bids']), 0, True),
        })

    async def edit_limit_buy_order(self, id: str, symbol: str, amount: float, price: Num = None, params: dict = {}):
        return await self.editLimitOrder(id, symbol, 'buy', amount, price, params)

    async def edit_limit_sell_order(self, id: str, symbol: str, amount: float, price: Num = None, params: dict = {}):
        return await self.editLimitOrder(id, symbol, 'sell', amount, price, params)

    async def edit_limit_order(self, id: str, symbol: str, side: OrderSide, amount: float, price: Num = None, params: dict = {}):
        return await self.editOrder(id, symbol, 'limit', side, amount, price, params)

    async def edit_order(self, id: str, symbol: str, type: OrderType, side: OrderSide, amount: Num = None, price: Num = None, params: dict = {}):
        await self.cancel_order(id, symbol)
        return await self.create_order(symbol, type, side, amount, price, params)

    async def edit_order_with_client_order_id(self, clientOrderId: str, symbol: str, type: OrderType, side: OrderSide, amount: Num = None, price: Num = None, params: dict = {}):
        extendedParams = self.extend(params, {'clientOrderId': clientOrderId})
        return await self.editOrder('', symbol, type, side, amount, price, extendedParams)

    async def fetch_position(self, symbol: str, params: dict = {}):
        raise NotSupported(self.id + ' fetchPosition() is not supported yet')

    async def watch_positions(self, symbols: Strings = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' watchPositions() is not supported yet')

    async def watch_position_for_symbols(self, symbols: Strings = None, since: Int = None, limit: Int = None, params: dict = {}):
        return await self.watch_positions(symbols, since, limit, params)

    async def fetch_positions(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchPositions() is not supported yet')

    async def fetch_ticker(self, symbol: str, params: dict = {}):
        if self.has['fetchTickers'] is not None and self.has['fetchTickers'] is not False:
            await self.load_markets()
            market = self.market(symbol)
            symbol = market['symbol']
            tickers = await self.fetch_tickers([symbol], params)
            ticker = self.safe_dict(tickers, symbol)
            if ticker is None:
                raise NullResponse(self.id + ' fetchTickers() could not find a ticker for ' + symbol)
            else:
                return ticker
        else:
            raise NotSupported(self.id + ' fetchTicker() is not supported yet')

    async def watch_ticker(self, symbol: str, params: dict = {}):
        raise NotSupported(self.id + ' watchTicker() is not supported yet')

    async def fetch_tickers(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchTickers() is not supported yet')

    async def watch_tickers(self, symbols: Strings = None, params: dict = {}):
        raise NotSupported(self.id + ' watchTickers() is not supported yet')

    async def fetch_order(self, id: str, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchOrder() is not supported yet')

    async def fetch_order_with_client_order_id(self, clientOrderId: str, symbol: Str = None, params: dict = {}):
        """
        create a market order by providing the symbol, side and cost
        :param str clientOrderId: client order Id
        :param str symbol: unified symbol of the market to create an order in
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        extendedParams = self.extend(params, {'clientOrderId': clientOrderId})
        return await self.fetchOrder('', symbol, extendedParams)

    async def fetch_order_status(self, id: str, symbol: Str = None, params: dict = {}):
        # TODO: TypeScript: change method signature by replacing
        # Promise<string> with Promise<Order['status']>.
        order = await self.fetchOrder(id, symbol, params)
        return order['status']

    async def fetch_unified_order(self, order: object, params: dict = {}):
        return await self.fetchOrder(self.safe_string(order, 'id'), self.safe_string(order, 'symbol'), params)

    async def create_order(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, params: dict = {}):
        raise NotSupported(self.id + ' createOrder() is not supported yet')

    async def create_trailing_amount_order(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, trailingAmount: Num = None, trailingTriggerPrice: Num = None, params: dict = {}):
        """
        create a trailing order by providing the symbol, type, side, amount, price and trailingAmount
        :param str symbol: unified symbol of the market to create an order in
        :param str type: 'market' or 'limit'
        :param str side: 'buy' or 'sell'
        :param float amount: how much you want to trade in units of the base currency, or number of contracts
        :param float [price]: the price for the order to be filled at, in units of the quote currency, ignored in market orders
        :param float trailingAmount: the quote amount to trail away from the current market price
        :param float [trailingTriggerPrice]: the price to activate a trailing order, default uses the price argument
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        if trailingAmount is None:
            raise ArgumentsRequired(self.id + ' createTrailingAmountOrder() requires a trailingAmount argument')
        params['trailingAmount'] = trailingAmount
        if trailingTriggerPrice is not None:
            params['trailingTriggerPrice'] = trailingTriggerPrice
        if self.has['createTrailingAmountOrder'] is not None and self.has['createTrailingAmountOrder'] is not False:
            return await self.create_order(symbol, type, side, amount, price, params)
        raise NotSupported(self.id + ' createTrailingAmountOrder() is not supported yet')

    async def create_trailing_percent_order(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, trailingPercent: Num = None, trailingTriggerPrice: Num = None, params: dict = {}):
        """
        create a trailing order by providing the symbol, type, side, amount, price and trailingPercent
        :param str symbol: unified symbol of the market to create an order in
        :param str type: 'market' or 'limit'
        :param str side: 'buy' or 'sell'
        :param float amount: how much you want to trade in units of the base currency, or number of contracts
        :param float [price]: the price for the order to be filled at, in units of the quote currency, ignored in market orders
        :param float trailingPercent: the percent to trail away from the current market price
        :param float [trailingTriggerPrice]: the price to activate a trailing order, default uses the price argument
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        if trailingPercent is None:
            raise ArgumentsRequired(self.id + ' createTrailingPercentOrder() requires a trailingPercent argument')
        params['trailingPercent'] = trailingPercent
        if trailingTriggerPrice is not None:
            params['trailingTriggerPrice'] = trailingTriggerPrice
        if self.has['createTrailingPercentOrder'] is not None and self.has['createTrailingPercentOrder'] is not False:
            return await self.create_order(symbol, type, side, amount, price, params)
        raise NotSupported(self.id + ' createTrailingPercentOrder() is not supported yet')

    async def create_market_order_with_cost(self, symbol: str, side: OrderSide, cost: float, params: dict = {}):
        """
        create a market order by providing the symbol, side and cost
        :param str symbol: unified symbol of the market to create an order in
        :param str side: 'buy' or 'sell'
        :param float cost: how much you want to trade in units of the quote currency
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        if (self.has['createMarketOrderWithCost'] is not None and self.has['createMarketOrderWithCost'] is not False) or ((self.has['createMarketBuyOrderWithCost'] is not None and self.has['createMarketBuyOrderWithCost'] is not False) and (self.has['createMarketSellOrderWithCost'] is not None and self.has['createMarketSellOrderWithCost'] is not False)):
            return await self.create_order(symbol, 'market', side, cost, 1, params)
        raise NotSupported(self.id + ' createMarketOrderWithCost() is not supported yet')

    async def create_market_buy_order_with_cost(self, symbol: str, cost: float, params: dict = {}):
        """
        create a market buy order by providing the symbol and cost
        :param str symbol: unified symbol of the market to create an order in
        :param float cost: how much you want to trade in units of the quote currency
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        if (self.options['createMarketBuyOrderRequiresPrice'] is True) or (self.has['createMarketBuyOrderWithCost'] is not None and self.has['createMarketBuyOrderWithCost'] is not False):
            return await self.create_order(symbol, 'market', 'buy', cost, 1, params)
        raise NotSupported(self.id + ' createMarketBuyOrderWithCost() is not supported yet')

    async def create_market_sell_order_with_cost(self, symbol: str, cost: float, params: dict = {}):
        """
        create a market sell order by providing the symbol and cost
        :param str symbol: unified symbol of the market to create an order in
        :param float cost: how much you want to trade in units of the quote currency
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        if (self.options['createMarketSellOrderRequiresPrice'] is True) or (self.has['createMarketSellOrderWithCost'] is not None and self.has['createMarketSellOrderWithCost'] is not False):
            return await self.create_order(symbol, 'market', 'sell', cost, 1, params)
        raise NotSupported(self.id + ' createMarketSellOrderWithCost() is not supported yet')

    async def create_trigger_order(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, triggerPrice: Num = None, params: dict = {}):
        """
        create a trigger stop order(type 1)
        :param str symbol: unified symbol of the market to create an order in
        :param str type: 'market' or 'limit'
        :param str side: 'buy' or 'sell'
        :param float amount: how much you want to trade in units of the base currency or the number of contracts
        :param float [price]: the price to fulfill the order, in units of the quote currency, ignored in market orders
        :param float triggerPrice: the price to trigger the stop order, in units of the quote currency
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        if triggerPrice is None:
            raise ArgumentsRequired(self.id + ' createTriggerOrder() requires a triggerPrice argument')
        params = self.extend(params, {'triggerPrice': triggerPrice})
        if self.has['createTriggerOrder'] is not None and self.has['createTriggerOrder'] is not False:
            return await self.create_order(symbol, type, side, amount, price, params)
        raise NotSupported(self.id + ' createTriggerOrder() is not supported yet')

    async def create_stop_loss_order(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, stopLossPrice: Num = None, params: dict = {}):
        """
        create a trigger stop loss order(type 2)
        :param str symbol: unified symbol of the market to create an order in
        :param str type: 'market' or 'limit'
        :param str side: 'buy' or 'sell'
        :param float amount: how much you want to trade in units of the base currency or the number of contracts
        :param float [price]: the price to fulfill the order, in units of the quote currency, ignored in market orders
        :param float stopLossPrice: the price to trigger the stop loss order, in units of the quote currency
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        if stopLossPrice is None:
            raise ArgumentsRequired(self.id + ' createStopLossOrder() requires a stopLossPrice argument')
        params = self.extend(params, {'stopLossPrice': stopLossPrice})
        if self.has['createStopLossOrder'] is not None and self.has['createStopLossOrder'] is not False:
            return await self.create_order(symbol, type, side, amount, price, params)
        raise NotSupported(self.id + ' createStopLossOrder() is not supported yet')

    async def create_take_profit_order(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, takeProfitPrice: Num = None, params: dict = {}):
        """
        create a trigger take profit order(type 2)
        :param str symbol: unified symbol of the market to create an order in
        :param str type: 'market' or 'limit'
        :param str side: 'buy' or 'sell'
        :param float amount: how much you want to trade in units of the base currency or the number of contracts
        :param float [price]: the price to fulfill the order, in units of the quote currency, ignored in market orders
        :param float takeProfitPrice: the price to trigger the take profit order, in units of the quote currency
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        if takeProfitPrice is None:
            raise ArgumentsRequired(self.id + ' createTakeProfitOrder() requires a takeProfitPrice argument')
        params = self.extend(params, {'takeProfitPrice': takeProfitPrice})
        if self.has['createTakeProfitOrder'] is not None and self.has['createTakeProfitOrder'] is not False:
            return await self.create_order(symbol, type, side, amount, price, params)
        raise NotSupported(self.id + ' createTakeProfitOrder() is not supported yet')

    async def create_order_with_take_profit_and_stop_loss(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, takeProfit: Num = None, stopLoss: Num = None, params: dict = {}):
        """
        create an order with a stop loss or take profit attached(type 3)
        :param str symbol: unified symbol of the market to create an order in
        :param str type: 'market' or 'limit'
        :param str side: 'buy' or 'sell'
        :param float amount: how much you want to trade in units of the base currency or the number of contracts
        :param float [price]: the price to fulfill the order, in units of the quote currency, ignored in market orders
        :param float [takeProfit]: the take profit price, in units of the quote currency
        :param float [stopLoss]: the stop loss price, in units of the quote currency
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :param str [params.takeProfitType]: *not available on all exchanges* 'limit' or 'market'
        :param str [params.stopLossType]: *not available on all exchanges* 'limit' or 'market'
        :param str [params.takeProfitPriceType]: *not available on all exchanges* 'last', 'mark' or 'index'
        :param str [params.stopLossPriceType]: *not available on all exchanges* 'last', 'mark' or 'index'
        :param float [params.takeProfitLimitPrice]: *not available on all exchanges* limit price for a limit take profit order
        :param float [params.stopLossLimitPrice]: *not available on all exchanges* stop loss for a limit stop loss order
        :param float [params.takeProfitAmount]: *not available on all exchanges* the amount for a take profit
        :param float [params.stopLossAmount]: *not available on all exchanges* the amount for a stop loss
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        params = self.set_take_profit_and_stop_loss_params(symbol, type, side, amount, price, takeProfit, stopLoss, params)
        if self.has['createOrderWithTakeProfitAndStopLoss'] is not None and self.has['createOrderWithTakeProfitAndStopLoss'] is not False:
            return await self.create_order(symbol, type, side, amount, price, params)
        raise NotSupported(self.id + ' createOrderWithTakeProfitAndStopLoss() is not supported yet')

    async def create_orders(self, orders: list[OrderRequest], params: dict = {}):
        raise NotSupported(self.id + ' createOrders() is not supported yet')

    async def cancel_order(self, id: str, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' cancelOrder() is not supported yet')

    async def cancel_order_with_client_order_id(self, clientOrderId: str, symbol: Str = None, params: dict = {}):
        """
        create a market order by providing the symbol, side and cost
        :param str clientOrderId: client order Id
        :param str symbol: unified symbol of the market to create an order in
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        extendedParams = self.extend(params, {'clientOrderId': clientOrderId})
        return await self.cancel_order('', symbol, extendedParams)

    async def cancel_orders(self, ids: list[str], symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' cancelOrders() is not supported yet')

    async def cancel_orders_with_client_order_ids(self, clientOrderIds: list[str], symbol: Str = None, params: dict = {}):
        """
        create a market order by providing the symbol, side and cost
        :param str[] clientOrderIds: client order Ids
        :param str symbol: unified symbol of the market to create an order in
        :param dict [params]: extra parameters specific to the exchange API endpoint
        :returns dict: an `order structure <https://docs.ccxt.com/?id=order-structure>`
        """
        extendedParams = self.extend(params, {'clientOrderIds': clientOrderIds})
        return await self.cancel_orders([], symbol, extendedParams)

    async def cancel_all_orders(self, symbol: Str = None, params: dict = {}):
        raise NotSupported(self.id + ' cancelAllOrders() is not supported yet')

    async def cancel_unified_order(self, order: Order, params: dict = {}):
        return self.cancel_order(self.safe_string(order, 'id'), self.safe_string(order, 'symbol'), params)

    async def fetch_orders(self, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        if (self.has['fetchOpenOrders'] is not None and self.has['fetchOpenOrders'] is not False) and (self.has['fetchClosedOrders'] is not None and self.has['fetchClosedOrders'] is not False):
            raise NotSupported(self.id + ' fetchOrders() is not supported yet, consider using fetchOpenOrders() and fetchClosedOrders() instead')
        raise NotSupported(self.id + ' fetchOrders() is not supported yet')

    async def fetch_order_trades(self, id: str, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchOrderTrades() is not supported yet')

    async def watch_orders(self, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' watchOrders() is not supported yet')

    async def fetch_open_orders(self, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        if self.has['fetchOrders'] is not None and self.has['fetchOrders'] is not False:
            orders = await self.fetch_orders(symbol, since, limit, params)
            return self.filter_by(orders, 'status', 'open')
        raise NotSupported(self.id + ' fetchOpenOrders() is not supported yet')

    async def fetch_closed_orders(self, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        if self.has['fetchOrders'] is not None and self.has['fetchOrders'] is not False:
            orders = await self.fetch_orders(symbol, since, limit, params)
            return self.filter_by(orders, 'status', 'closed')
        raise NotSupported(self.id + ' fetchClosedOrders() is not supported yet')

    async def fetch_canceled_orders(self, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchCanceledOrders() is not supported yet')

    async def fetch_my_trades(self, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' fetchMyTrades() is not supported yet')

    async def watch_my_trades(self, symbol: Str = None, since: Int = None, limit: Int = None, params: dict = {}):
        raise NotSupported(self.id + ' watchMyTrades() is not supported yet')

    async def create_limit_order(self, symbol: str, side: OrderSide, amount: float, price: float, params: dict = {}):
        return await self.create_order(symbol, 'limit', side, amount, price, params)

    async def create_market_order(self, symbol: str, side: OrderSide, amount: float, price: Num = None, params: dict = {}):
        return await self.create_order(symbol, 'market', side, amount, price, params)

    async def create_limit_buy_order(self, symbol: str, amount: float, price: float, params: dict = {}):
        return await self.create_order(symbol, 'limit', 'buy', amount, price, params)

    async def create_limit_sell_order(self, symbol: str, amount: float, price: float, params: dict = {}):
        return await self.create_order(symbol, 'limit', 'sell', amount, price, params)

    async def create_market_buy_order(self, symbol: str, amount: float, params: dict = {}):
        return await self.create_order(symbol, 'market', 'buy', amount, None, params)

    async def create_market_sell_order(self, symbol: str, amount: float, params: dict = {}):
        return await self.create_order(symbol, 'market', 'sell', amount, None, params)

    async def create_post_only_order(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, params: dict = {}):
        if self.has['createPostOnlyOrder'] is None or self.has['createPostOnlyOrder'] is False:
            raise NotSupported(self.id + ' createPostOnlyOrder() is not supported yet')
        query = self.extend(params, {'postOnly': True})
        return await self.create_order(symbol, type, side, amount, price, query)

    async def create_reduce_only_order(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, params: dict = {}):
        if self.has['createReduceOnlyOrder'] is None or self.has['createReduceOnlyOrder'] is False:
            raise NotSupported(self.id + ' createReduceOnlyOrder() is not supported yet')
        query = self.extend(params, {'reduceOnly': True})
        return await self.create_order(symbol, type, side, amount, price, query)

    async def create_stop_order(self, symbol: str, type: OrderType, side: OrderSide, amount: float, price: Num = None, triggerPrice: Num = None, params: dict = {}):
        if self.has['createStopOrder'] is None or self.has['createStopOrder'] is False:
            raise NotSupported(self.id + ' createStopOrder() is not supported yet')
        if triggerPrice is None:
            raise ArgumentsRequired(self.id + ' create_stop_order() requires a stopPrice argument')
        query = self.extend(params, {'stopPrice': triggerPrice})
        return await self.create_order(symbol, type, side, amount, price, query)

    async def create_stop_limit_order(self, symbol: str, side: OrderSide, amount: float, price: float, triggerPrice: float, params: dict = {}):
        if self.has['createStopLimitOrder'] is None or self.has['createStopLimitOrder'] is False:
            raise NotSupported(self.id + ' createStopLimitOrder() is not supported yet')
        query = self.extend(params, {'stopPrice': triggerPrice})
        return await self.create_order(symbol, 'limit', side, amount, price, query)

    async def create_stop_market_order(self, symbol: str, side: OrderSide, amount: float, triggerPrice: float, params: dict = {}):
        if self.has['createStopMarketOrder'] is None or self.has['createStopMarketOrder'] is False:
            raise NotSupported(self.id + ' createStopMarketOrder() is not supported yet')
        query = self.extend(params, {'stopPrice': triggerPrice})
        return await self.create_order(symbol, 'market', side, amount, None, query)

    async def fetch_trading_fee(self, symbol: str, params: dict = {}):
        if self.has['fetchTradingFees'] is None or self.has['fetchTradingFees'] is False:
            raise NotSupported(self.id + ' fetchTradingFee() is not supported yet')
        fees = await self.fetch_trading_fees(params)
        return self.safe_dict(fees, symbol)
